# API Reference — Upsilon Helpdesk & SAV
## Intégration Django Backend

Ce fichier décrit tous les endpoints REST attendus par le front React.
Le collègue Django remplace le contenu de `src/services/api.ts` par des appels `fetch()` vers ces URLs.

---

## Auth

### POST /api/auth/login/
**Body** `{ email, password }`
**Response** `{ token: string, user: User }`

### POST /api/auth/logout/
**Headers** `Authorization: Bearer <token>`
**Response** `204`

---

## Users

### GET /api/users/
Liste tous les utilisateurs (admin uniquement)
**Response** `User[]`

### GET /api/users/?role=client|engineer|commercial|admin
Filtre par rôle
**Response** `User[]`

### GET /api/users/:id/
**Response** `User`

### POST /api/users/
Créer un utilisateur (admin / commercial)
**Body** `{ email, fullName, role, company?, phone? }`
**Response** `User`

### DELETE /api/users/:id/
Supprimer un utilisateur (admin uniquement)
**Response** `204`

### PATCH /api/users/:id/
Mettre à jour (ex: assignedEngineerId)
**Body** `Partial<User>`
**Response** `User`

---

## Equipments

### GET /api/equipments/
**Response** `Equipment[]`

### GET /api/equipments/?client_id=:id
Filtre par client
**Response** `Equipment[]`

---

## Contracts

### GET /api/contracts/
**Response** `Contract[]`

### GET /api/contracts/?client_id=:id
**Response** `Contract[]`

### GET /api/contracts/?engineer_id=:id
Contrats des clients assignés à cet ingénieur
**Response** `Contract[]`

### POST /api/contracts/
Créer un contrat (commercial uniquement)
**Body** `{ clientId, clientName, startDate, endDate, scope, equipmentIds, amount? }`
**Response** `Contract`

### PATCH /api/contracts/:id/renew/
Renouveler un contrat (commercial uniquement)
**Body** `{ newStartDate: string, newEndDate: string }`
**Response** `Contract`

---

## Tickets

### GET /api/tickets/
**Response** `Ticket[]`

### GET /api/tickets/?client_id=:id
**Response** `Ticket[]`

### GET /api/tickets/?engineer_id=:id
**Response** `Ticket[]`

### GET /api/tickets/:id/
**Response** `Ticket`

### POST /api/tickets/
**Body** `{ subject, description, category, priority, status, clientId, clientName, equipmentId, equipmentSerial, equipmentLabel, contractId?, slaDueAt }`
**Response** `Ticket`

### PATCH /api/tickets/:id/
Mise à jour partielle (statut, assignee, escalade…)
**Body** `Partial<Ticket>`
**Response** `Ticket`

### POST /api/tickets/:id/messages/
Ajouter un message ou une pièce jointe
**Body** `{ authorId, authorName, authorRole, authorInitials, content, attachments? }`
**Response** `Ticket` (avec messages mis à jour)

---

## Maintenances

### GET /api/maintenances/
**Response** `Maintenance[]`

### GET /api/maintenances/?client_id=:id
**Response** `Maintenance[]`

### GET /api/maintenances/?engineer_id=:id
**Response** `Maintenance[]`

### POST /api/maintenances/
Planifier une maintenance (ingénieur uniquement)
**Body** `{ type, status, clientId, clientName, equipmentId, equipmentSerial, engineerId, engineerName, scheduledAt, durationMinutes, notes? }`
**Response** `Maintenance`
**Side-effect** Email de notification envoyé au client

### POST /api/maintenances/:id/upload-report/
Upload du rapport PDF (ingénieur uniquement)
**Body** `multipart/form-data { file: PDF }`
**Response** `Maintenance`
**Side-effect** Email de validation envoyé au client

---

## KB (Base de connaissances)

### GET /api/kb/
**Response** `KbArticle[]`

---

## Types TypeScript (référence)

```ts
type UserRole = "client" | "engineer" | "commercial" | "admin";

interface User {
  id: string; email: string; fullName: string; initials: string;
  role: UserRole; company?: string; phone?: string;
  createdAt: string; assignedEngineerId?: string;
}

type TicketStatus = "ouvert" | "en_cours" | "en_attente" | "resolu" | "ferme";
type TicketPriority = "faible" | "moyenne" | "haute" | "critique";
type TicketCategory = "panne" | "demande" | "incident" | "maintenance" | "autre";

interface Ticket {
  id: string; reference: string; subject: string; description: string;
  category: TicketCategory; status: TicketStatus; priority: TicketPriority;
  clientId: string; clientName: string; equipmentId: string;
  equipmentSerial: string; equipmentLabel: string; contractId?: string;
  assigneeId?: string; assigneeName?: string; assigneeInitials?: string;
  createdAt: string; updatedAt: string; slaDueAt: string;
  escalated?: boolean; messages: TicketMessage[];
}

type ContractStatus = "actif" | "expire_bientot" | "expire" | "renouvele";

interface Contract {
  id: string; reference: string; clientId: string; clientName: string;
  startDate: string; endDate: string; status: ContractStatus;
  scope: string; equipmentIds: string[]; amount?: number; createdBy?: string;
}

type MaintenanceType = "preventive" | "curative";
type MaintenanceStatus = "planifiee" | "en_cours" | "realisee" | "annulee";

interface Maintenance {
  id: string; reference: string; type: MaintenanceType; status: MaintenanceStatus;
  clientId: string; clientName: string; equipmentId: string;
  equipmentSerial: string; engineerId: string; engineerName: string;
  scheduledAt: string; durationMinutes: number; notes?: string;
  reportPdfName?: string; reportUploadedAt?: string;
}
```

---

## Notes d'intégration

1. **Token JWT** : à stocker dans `localStorage` sous la clé `upsilon_token` et injecté dans chaque requête via `Authorization: Bearer <token>`
2. **Base URL** : définir `VITE_API_BASE_URL=http://localhost:8000` dans `.env`
3. **CORS** : configurer `django-cors-headers` pour autoriser l'origine du front
4. **Emails** : utiliser `django-anymail` ou `smtplib` pour les notifications maintenance
5. **Upload PDF** : utiliser `django-storages` + S3 ou servir les fichiers via `/media/`
