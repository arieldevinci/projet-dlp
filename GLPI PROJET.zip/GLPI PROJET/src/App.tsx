import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { AppLayout } from "@/components/layout/AppLayout";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";

import Login from "./pages/Login";
import DashboardRouter from "./pages/DashboardRouter";
import NotFound from "./pages/NotFound.tsx";

// Client
import ClientTickets from "./pages/client/ClientTickets";
import NewTicket from "./pages/client/NewTicket";
import ClientContracts from "./pages/client/ClientContracts";
import ClientMaintenances from "./pages/client/ClientMaintenances";
import ClientEquipments from "./pages/client/ClientEquipments";

// Shared
import TicketDetail from "./pages/shared/TicketDetail";

// Engineer
import EngineerTickets from "./pages/engineer/EngineerTickets";
import EngineerMaintenance from "./pages/engineer/EngineerMaintenance";
import NewEngineerTicket from "./pages/engineer/NewEngineerTicket";

// Commercial
import CommercialContracts from "./pages/commercial/CommercialContracts";
import CommercialClients from "./pages/commercial/CommercialClients";

// Admin
import AdminTickets from "./pages/admin/AdminTickets";
import AdminUsers from "./pages/admin/AdminUsers";
import ProfilePage from "./pages/shared/ProfilePage";
import AdminStatistics from "./pages/admin/AdminStatistics";
import AdminEscalations from "./pages/admin/AdminEscalations";
import AdminAssignments from "./pages/admin/AdminAssignments";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />

            <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route path="/" element={<DashboardRouter />} />

              {/* Client */}
              <Route path="/mes-tickets" element={<ProtectedRoute roles={["client"]}><ClientTickets /></ProtectedRoute>} />
              <Route path="/mes-tickets/nouveau" element={<ProtectedRoute roles={["client"]}><NewTicket /></ProtectedRoute>} />
              <Route path="/mes-tickets/:id" element={<ProtectedRoute roles={["client", "engineer", "admin"]}><TicketDetail /></ProtectedRoute>} />
              <Route path="/profil" element={<ProtectedRoute roles={["client", "engineer", "commercial", "admin"]}><ProfilePage /></ProtectedRoute>} />
              <Route path="/mes-contrats" element={<ProtectedRoute roles={["client"]}><ClientContracts /></ProtectedRoute>} />
              <Route path="/mes-maintenances" element={<ProtectedRoute roles={["client"]}><ClientMaintenances /></ProtectedRoute>} />
              <Route path="/mes-equipements" element={<ProtectedRoute roles={["client"]}><ClientEquipments /></ProtectedRoute>} />

              {/* Engineer */}
              <Route path="/ing/tickets" element={<ProtectedRoute roles={["engineer"]}><EngineerTickets /></ProtectedRoute>} />
              <Route path="/ing/tickets/nouveau" element={<ProtectedRoute roles={["engineer"]}><NewEngineerTicket /></ProtectedRoute>} />
              <Route path="/ing/maintenance" element={<ProtectedRoute roles={["engineer"]}><EngineerMaintenance /></ProtectedRoute>} />
              <Route path="/ing/contrats" element={<ProtectedRoute roles={["engineer"]}><CommercialContracts /></ProtectedRoute>} />

              {/* Commercial */}
              <Route path="/co/contrats" element={<ProtectedRoute roles={["commercial"]}><CommercialContracts /></ProtectedRoute>} />
              <Route path="/co/renouvellements" element={<ProtectedRoute roles={["commercial"]}><CommercialContracts /></ProtectedRoute>} />
              <Route path="/co/clients" element={<ProtectedRoute roles={["commercial", "admin"]}><CommercialClients /></ProtectedRoute>} />

              {/* Admin */}
              <Route path="/admin/tickets" element={<ProtectedRoute roles={["admin"]}><AdminTickets /></ProtectedRoute>} />
              <Route path="/admin/escalades" element={<ProtectedRoute roles={["admin"]}><AdminEscalations /></ProtectedRoute>} />
              <Route path="/admin/maintenance" element={<ProtectedRoute roles={["admin"]}><EngineerMaintenance /></ProtectedRoute>} />
              <Route path="/admin/attributions" element={<ProtectedRoute roles={["admin"]}><AdminAssignments /></ProtectedRoute>} />
              <Route path="/admin/contrats" element={<ProtectedRoute roles={["admin"]}><CommercialContracts /></ProtectedRoute>} />
              <Route path="/admin/utilisateurs" element={<ProtectedRoute roles={["admin"]}><AdminUsers /></ProtectedRoute>} />
              <Route path="/admin/statistiques" element={<ProtectedRoute roles={["admin"]}><AdminStatistics /></ProtectedRoute>} />

              {/* Shared */}
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
