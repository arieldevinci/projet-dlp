import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { User, UserRole } from "@/types";
import { users as seedUsers } from "@/data/seed";

/**
 * AuthContext mocké — sera remplacé par appels Django (JWT) plus tard.
 * Persiste l'utilisateur courant dans localStorage pour la démo.
 */

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  loginAs: (role: UserRole) => User;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const STORAGE_KEY = "upsilon.auth.user";

// Comptes de démo (un par rôle) — pour faciliter les tests
const demoByRole: Record<UserRole, string> = {
  client: "u-c-01",
  engineer: "u-e-01",
  commercial: "u-co-01",
  admin: "u-a-01",
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setUser(JSON.parse(raw));
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setLoading(false);
  }, []);

  const persist = (u: User | null) => {
    setUser(u);
    if (u) localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    else localStorage.removeItem(STORAGE_KEY);
  };

  const login = async (email: string, _password: string): Promise<User> => {
    await new Promise((r) => setTimeout(r, 350));
    const found = seedUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!found) throw new Error("Identifiants invalides");
    persist(found);
    return found;
  };

  const loginAs = (role: UserRole): User => {
    const u = seedUsers.find((x) => x.id === demoByRole[role])!;
    persist(u);
    return u;
  };

  const logout = () => persist(null);

  return (
    <AuthContext.Provider value={{ user, loading, login, loginAs, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
