import { formatDistanceToNow, formatDistanceToNowStrict } from "date-fns";
import { fr } from "date-fns/locale";

export const fmtRelative = (iso: string) =>
  formatDistanceToNow(new Date(iso), { addSuffix: true, locale: fr });

export const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });

export const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString("fr-FR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

export const slaInfo = (slaDueAt: string) => {
  const diff = new Date(slaDueAt).getTime() - Date.now();
  const breached = diff < 0;
  const hours = Math.abs(diff) / (1000 * 3600);
  const text = breached
    ? `Dépassé de ${formatDistanceToNowStrict(new Date(slaDueAt), { locale: fr })}`
    : `${formatDistanceToNowStrict(new Date(slaDueAt), { locale: fr })} restant`;
  const tone = breached
    ? "text-destructive"
    : hours < 4
    ? "text-warning-foreground"
    : "text-success";
  return { breached, text, tone };
};
