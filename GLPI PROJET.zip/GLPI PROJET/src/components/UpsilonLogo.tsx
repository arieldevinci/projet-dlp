import logo from "@/assets/Couleur 50 mm.png";
import { cn } from "@/lib/utils";

interface UpsilonLogoProps {
  className?: string;
  variant?: "default" | "light";
}

/** Renders the UPSILON Business Solutions logo. Use `light` on dark surfaces. */
export const UpsilonLogo = ({ className, variant = "default" }: UpsilonLogoProps) => {
  return (
    <img
      src={logo}
      alt="UPSILON Business Solutions"
      className={cn(
        "h-7 md:h-14 w-auto object-contain",
        className,
      )}
      draggable={false}
    />
  );
};
