import { cn } from "@/lib/utils";

export type TicketStatus = "ouvert" | "en_cours" | "en_attente" | "resolu" | "ferme";
export type TicketPriority = "faible" | "moyenne" | "haute" | "critique";

const statusConfig: Record<TicketStatus, { label: string; classes: string }> = {
  ouvert: { label: "Ouvert", classes: "bg-info/10 text-info ring-info/20" },
  en_cours: { label: "En cours", classes: "bg-accent/15 text-accent ring-accent/30" },
  en_attente: { label: "En attente", classes: "bg-warning/15 text-warning-foreground ring-warning/40" },
  resolu: { label: "Résolu", classes: "bg-success/10 text-success ring-success/30" },
  ferme: { label: "Fermé", classes: "bg-muted text-muted-foreground ring-border" },
};

const priorityConfig: Record<TicketPriority, { label: string; classes: string }> = {
  faible: { label: "Faible", classes: "bg-muted text-muted-foreground" },
  moyenne: { label: "Moyenne", classes: "bg-info/10 text-info" },
  haute: { label: "Haute", classes: "bg-accent/15 text-accent" },
  critique: { label: "Critique", classes: "bg-destructive/10 text-destructive" },
};

export const StatusBadge = ({ status }: { status: TicketStatus }) => {
  const cfg = statusConfig[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset",
        cfg.classes,
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {cfg.label}
    </span>
  );
};

export const PriorityBadge = ({ priority }: { priority: TicketPriority }) => {
  const cfg = priorityConfig[priority];
  return (
    <span className={cn("inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium", cfg.classes)}>
      {cfg.label}
    </span>
  );
};
