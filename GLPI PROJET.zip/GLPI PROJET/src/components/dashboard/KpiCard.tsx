import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KpiCardProps {
  label: string;
  value: string | number;
  delta?: number;
  hint?: string;
  icon: LucideIcon;
  accent?: "primary" | "accent" | "success" | "warning" | "destructive" | "info";
}

const accentClasses: Record<NonNullable<KpiCardProps["accent"]>, string> = {
  primary: "bg-primary/10 text-primary",
  accent: "bg-accent/15 text-accent",
  success: "bg-success/10 text-success",
  warning: "bg-warning/15 text-warning-foreground",
  destructive: "bg-destructive/10 text-destructive",
  info: "bg-info/10 text-info",
};

export const KpiCard = ({ label, value, delta, hint, icon: Icon, accent = "primary" }: KpiCardProps) => {
  const positive = (delta ?? 0) >= 0;
  return (
    <Card className="group relative overflow-hidden p-5 transition-shadow hover:shadow-soft">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="text-3xl font-bold tracking-tight text-foreground">{value}</p>
          {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
        </div>
        <div className={cn("flex h-10 w-10 items-center justify-center rounded-lg", accentClasses[accent])}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      {typeof delta === "number" && (
        <div className="mt-3 flex items-center gap-1 text-xs font-medium">
          {positive ? (
            <TrendingUp className="h-3.5 w-3.5 text-success" />
          ) : (
            <TrendingDown className="h-3.5 w-3.5 text-destructive" />
          )}
          <span className={positive ? "text-success" : "text-destructive"}>
            {positive ? "+" : ""}
            {delta}%
          </span>
          <span className="text-muted-foreground">vs. semaine dernière</span>
        </div>
      )}
      <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-accent opacity-0 transition-opacity group-hover:opacity-100" />
    </Card>
  );
};
