import {
  LayoutDashboard, Ticket, FileSignature, Wrench, Users, BarChart3,
  Settings, LogOut, Package, Calendar, UserPlus, ShieldCheck, UserCircle,
} from "lucide-react";
import { NavLink, Link, useLocation, useNavigate } from "react-router-dom";

import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton,
  SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";
import { UpsilonLogo } from "@/components/UpsilonLogo";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import type { UserRole } from "@/types";

interface NavItem {
  title: string;
  url: string;
  icon: typeof Ticket;
  end?: boolean;
}

const navByRole: Record<UserRole, { label: string; items: NavItem[] }[]> = {
  client: [
    {
      label: "Mon espace",
      items: [
        { title: "Tableau de bord", url: "/", icon: LayoutDashboard, end: true },
        { title: "Mes tickets", url: "/mes-tickets", icon: Ticket },
        { title: "Mes contrats", url: "/mes-contrats", icon: FileSignature },
        { title: "Mes maintenances", url: "/mes-maintenances", icon: Wrench },
        { title: "Mes équipements", url: "/mes-equipements", icon: Package },
      ],
    },
  ],
  engineer: [
    {
      label: "Opérations",
      items: [
        { title: "Tableau de bord", url: "/", icon: LayoutDashboard, end: true },
        { title: "Mes tickets", url: "/ing/tickets", icon: Ticket },
        { title: "Planning maintenance", url: "/ing/maintenance", icon: Calendar },
        { title: "Contrats assignés", url: "/ing/contrats", icon: FileSignature },
      ],
    },
  ],
  commercial: [
    {
      label: "Commercial",
      items: [
        { title: "Tableau de bord", url: "/", icon: LayoutDashboard, end: true },
        { title: "Contrats", url: "/co/contrats", icon: FileSignature },
        { title: "Renouvellements", url: "/co/renouvellements", icon: Calendar },
        { title: "Clients", url: "/co/clients", icon: Users },
      ],
    },
  ],
  admin: [
    {
      label: "Pilotage",
      items: [
        { title: "Tableau de bord", url: "/", icon: LayoutDashboard, end: true },
        { title: "Tous les tickets", url: "/admin/tickets", icon: Ticket },
        { title: "Escalades", url: "/admin/escalades", icon: ShieldCheck },
        { title: "Maintenances", url: "/admin/maintenance", icon: Wrench },
        { title: "Attributions clients", url: "/admin/attributions", icon: UserPlus },
        { title: "Contrats", url: "/admin/contrats", icon: FileSignature },
      ],
    },
    {
      label: "Administration",
      items: [
        { title: "Utilisateurs", url: "/admin/utilisateurs", icon: Users },
        { title: "Statistiques", url: "/admin/statistiques", icon: BarChart3 },
      ],
    },
  ],
};

const roleLabel: Record<UserRole, string> = {
  client: "Client",
  engineer: "Ingénieur",
  commercial: "Commercial",
  admin: "Super Admin",
};

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  if (!user) return null;
  const groups = navByRole[user.role];

  const renderItem = (item: NavItem) => {
    const isActive = item.end
      ? location.pathname === item.url
      : location.pathname.startsWith(item.url);
    return (
      <SidebarMenuItem key={item.title}>
        <SidebarMenuButton
          asChild
          tooltip={collapsed ? item.title : undefined}
          className={cn(
            "transition-colors",
            isActive
              ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
              : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
          )}
        >
          <NavLink to={item.url} end={item.end}>
            <item.icon className="h-4 w-4" />
            {!collapsed && <span className="flex-1">{item.title}</span>}
          </NavLink>
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  };

  return (
    <Sidebar collapsible="icon" className="border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border/60 py-4">
        <div className={cn("flex items-center gap-2 px-2", collapsed && "justify-center px-0")}>
          {collapsed ? (
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent text-accent-foreground font-extrabold text-lg">
              U
            </div>
          ) : (
            <UpsilonLogo variant="light" className="h-8" />
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="px-2">
        {groups.map((group) => (
          <SidebarGroup key={group.label}>
            <SidebarGroupLabel className="text-sidebar-foreground/50 uppercase tracking-wider text-[10px]">
              {group.label}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>{group.items.map(renderItem)}</SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border/60 p-3">
        <div className={cn("flex items-center gap-3", collapsed && "justify-center")}>
          <div className="h-9 w-9 shrink-0 rounded-full bg-gradient-accent flex items-center justify-center text-accent-foreground font-bold text-sm">
            {user.initials}
          </div>
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-sidebar-foreground">{user.fullName}</p>
              <p className="truncate text-xs text-sidebar-foreground/60">
                {roleLabel[user.role]}
                {user.company ? ` · ${user.company}` : ""}
              </p>
            </div>
          )}
          {!collapsed && (
            <div className="flex items-center gap-2">
              <Link
                to="/profil"
                className="text-sidebar-foreground/60 hover:text-sidebar-foreground transition-colors"
                aria-label="Mon profil"
                title="Mon profil"
              >
                <UserCircle className="h-4 w-4" />
              </Link>
              <button
                onClick={() => {
                  logout();
                  navigate("/login");
                }}
                className="text-sidebar-foreground/60 hover:text-sidebar-foreground transition-colors"
                aria-label="Déconnexion"
                title="Déconnexion"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
