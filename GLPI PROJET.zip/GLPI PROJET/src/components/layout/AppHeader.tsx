import { Bell, Search, HelpCircle, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export function AppHeader({ title, subtitle, actions }: AppHeaderProps) {
  const { user } = useAuth();
  // CDC : seuls le client et l'ingénieur peuvent créer un ticket
  const canCreateTicket = user?.role === "client" || user?.role === "engineer";
  const ticketPath = user?.role === "engineer" ? "/ing/tickets/nouveau" : "/mes-tickets/nouveau";
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur-md md:px-6">
      <SidebarTrigger className="text-muted-foreground hover:text-foreground" />

      <div className="hidden md:flex flex-col leading-tight">
        <h1 className="text-base font-semibold text-foreground">{title}</h1>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>

      <div className="ml-auto flex items-center gap-2">
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Rechercher un ticket, client, n° de série…"
            className="w-72 pl-9 bg-secondary border-transparent focus-visible:bg-background"
          />
          <kbd className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border bg-background px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground">
            ⌘K
          </kbd>
        </div>

        <Button variant="ghost" size="icon" aria-label="Aide">
          <HelpCircle className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" aria-label="Notifications" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-accent animate-pulse-glow" />
        </Button>

        {actions ?? (
          canCreateTicket ? (
            <Button variant="hero" size="sm" className="hidden sm:inline-flex" asChild>
              <Link to={ticketPath}>
                <Plus className="h-4 w-4" />
                Nouveau ticket
              </Link>
            </Button>
          ) : null
        )}
      </div>
    </header>
  );
}
