// ============================================================
// Types métier — UPSILON Helpdesk & SAV
// Aligné sur le futur schéma Django. Conserve les noms côté API
// pour faciliter la sérialisation.
// ============================================================

export type UserRole = "client" | "engineer" | "commercial" | "admin";

export interface User {
  id: string;
  email: string;
  fullName: string;
  initials: string;
  role: UserRole;
  company?: string; // pour les clients
  phone?: string;
  createdAt: string;
  /** Pour les clients : ingénieur référent attribué par le Super Admin (maintenance) */
  assignedEngineerId?: string;
}

// -------- Tickets ----------
export type TicketStatus = "ouvert" | "en_cours" | "en_attente" | "resolu" | "ferme";
export type TicketPriority = "faible" | "moyenne" | "haute" | "critique";
export type TicketCategory = "panne" | "demande" | "incident" | "maintenance" | "autre";

export interface TicketMessage {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorInitials: string;
  content: string;
  createdAt: string;
  attachments?: { name: string; size: string; url: string }[];
  internal?: boolean; // note interne ingénieur
}

export interface Ticket {
  id: string;
  reference: string; // TKT-2418
  subject: string;
  description: string;
  category: TicketCategory;
  status: TicketStatus;
  priority: TicketPriority;
  clientId: string;
  clientName: string;
  equipmentId: string;
  equipmentSerial: string;
  equipmentLabel: string;
  contractId?: string;
  assigneeId?: string;
  assigneeName?: string;
  assigneeInitials?: string;
  createdAt: string;
  updatedAt: string;
  slaDueAt: string;
  escalated?: boolean;
  messages: TicketMessage[];
}

// -------- Équipements / Garanties ----------
export interface Equipment {
  id: string;
  serial: string;
  label: string;
  type: string; // Onduleur, Serveur, Imprimante…
  brand: string;
  model: string;
  clientId: string;
  contractId?: string;
  warrantyEnd: string;
  installedAt: string;
}

// -------- Contrats ----------
export type ContractStatus = "actif" | "expire_bientot" | "expire" | "renouvele";

export interface Contract {
  id: string;
  reference: string; // CTR-2024-018
  clientId: string;
  clientName: string;
  startDate: string;
  endDate: string;
  status: ContractStatus;
  scope: string; // périmètre couvert
  equipmentIds: string[];
  amount?: number;
  createdBy?: string;
}

// -------- Maintenances ----------
export type MaintenanceType = "preventive" | "curative";
export type MaintenanceStatus = "planifiee" | "en_cours" | "realisee" | "annulee";

export interface Maintenance {
  id: string;
  reference: string;
  type: MaintenanceType;
  status: MaintenanceStatus;
  clientId: string;
  clientName: string;
  equipmentId: string;
  equipmentSerial: string;
  engineerId: string;
  engineerName: string;
  scheduledAt: string; // ISO datetime
  durationMinutes: number;
  notes?: string;
  reportPdfName?: string;
  reportUploadedAt?: string;
}

// -------- KB ----------
export interface KbArticle {
  id: string;
  category: string;
  title: string;
  excerpt: string;
  views: number;
  updatedAt: string;
}
