import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { ArrowRight, Briefcase, HardHat, Lock, Mail, Shield, User as UserIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UpsilonLogo } from "@/components/UpsilonLogo";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import type { UserRole } from "@/types";

const demoAccounts: { role: UserRole; label: string; email: string; icon: typeof UserIcon; description: string }[] = [
  { role: "client", label: "Client", email: "amine.belhaj@biat.tn", icon: UserIcon, description: "Voir mes tickets, contrats et maintenances" },
  { role: "engineer", label: "Ingénieur", email: "karim.belhaj@upsilon.tn", icon: HardHat, description: "Traiter les tickets et planifier les SAV" },
  { role: "commercial", label: "Commercial", email: "rania.zouari@upsilon.tn", icon: Briefcase, description: "Gérer les contrats et les clients" },
  { role: "admin", label: "Super Admin", email: "sophie.aboud@upsilon.tn", icon: Shield, description: "Pilotage complet de la plateforme" },
];

const Login = () => {
  const { user, login, loginAs } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const u = await login(email, password);
      toast({ title: `Bienvenue ${u.fullName}`, description: "Connexion réussie." });
      navigate("/");
    } catch (err) {
      toast({
        title: "Échec de la connexion",
        description: (err as Error).message,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemo = (role: UserRole) => {
    const u = loginAs(role);
    toast({ title: `Connecté en tant que ${u.fullName}`, description: `Rôle : ${role}` });
    navigate("/");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid gap-8 lg:grid-cols-2">
        {/* Branding side */}
        <div className="hidden lg:flex flex-col justify-between text-primary-foreground p-8">
          <UpsilonLogo variant="light" className="h-10" />
          <div>
            <h1 className="text-4xl font-bold leading-tight">
              Plateforme <span className="text-accent">Helpdesk & SAV</span>
            </h1>
            <p className="mt-4 text-primary-foreground/70 max-w-md">
              Centralisez vos tickets, contrats et maintenances. Une vue claire pour vos clients, vos
              ingénieurs et vos équipes commerciales.
            </p>
            <ul className="mt-8 space-y-3 text-sm">
              {[
                "Tickets en temps réel avec SLA",
                "Planning maintenance préventive & curative",
                "Suivi des contrats et renouvellements",
                "Statistiques de performance ingénieurs",
              ].map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <p className="text-xs text-primary-foreground/50">© UPSILON Business Solutions · 2026</p>
        </div>

        {/* Form side */}
        <Card className="p-6 md:p-8 shadow-elevated">
          <div className="lg:hidden mb-6 flex justify-center">
            <UpsilonLogo className="h-10" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight">Connexion</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Accédez à votre espace UPSILON Helpdesk.
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Adresse email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="vous@entreprise.tn"
                  className="pl-9"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Mot de passe</Label>
                <button type="button" className="text-xs text-accent hover:underline">
                  Mot de passe oublié ?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  className="pl-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <Button type="submit" variant="hero" className="w-full" disabled={submitting}>
              {submitting ? "Connexion…" : "Se connecter"}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </form>

          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs uppercase tracking-wider text-muted-foreground">
              Ou tester un rôle
            </span>
            <div className="h-px flex-1 bg-border" />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {demoAccounts.map((d) => (
              <button
                key={d.role}
                type="button"
                onClick={() => handleDemo(d.role)}
                className="group flex items-start gap-3 rounded-lg border bg-secondary/40 p-3 text-left transition-all hover:border-accent hover:bg-accent/5"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                  <d.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">{d.label}</p>
                  <p className="truncate text-[11px] text-muted-foreground">{d.description}</p>
                </div>
              </button>
            ))}
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            🔧 Démo front-end. Le back Django sera branché ultérieurement.
          </p>
        </Card>
      </div>
    </div>
  );
};

export default Login;
