import { useEffect, useMemo, useState } from "react";
import { Search, UserCheck } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usersService } from "@/services/api";
import type { User } from "@/types";
import { toast } from "@/hooks/use-toast";

/**
 * Vue Super Admin — Attribution des clients aux ingénieurs (cf. cahier de charge :
 * « Maintenance : attribution des clients aux ingénieurs. »)
 *
 * Chaque client peut être rattaché à un ingénieur référent qui pilotera
 * sa maintenance préventive et curative.
 */
const AdminAssignments = () => {
  const [clients, setClients] = useState<User[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [query, setQuery] = useState("");

  const load = async () => {
    const [c, e] = await Promise.all([
      usersService.byRole("client"),
      usersService.byRole("engineer"),
    ]);
    setClients(c);
    setEngineers(e);
  };

  useEffect(() => {
    load();
  }, []);

  const handleAssign = async (client: User, engineerId: string) => {
    const eng = engineers.find((e) => e.id === engineerId);
    if (!eng) return;
    // Mise à jour locale (le back Django persistera côté API)
    setClients((arr) =>
      arr.map((c) => (c.id === client.id ? { ...c, assignedEngineerId: eng.id } : c)),
    );
    toast({
      title: "Client attribué",
      description: `${client.company ?? client.fullName} → ${eng.fullName}`,
    });
  };

  const filtered = useMemo(
    () =>
      clients.filter((c) => {
        const q = query.toLowerCase().trim();
        if (!q) return true;
        return (
          c.fullName.toLowerCase().includes(q) ||
          (c.company ?? "").toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q)
        );
      }),
    [clients, query],
  );

  const stats = useMemo(() => {
    const counts: Record<string, number> = {};
    clients.forEach((c) => {
      if (c.assignedEngineerId) counts[c.assignedEngineerId] = (counts[c.assignedEngineerId] ?? 0) + 1;
    });
    return counts;
  }, [clients]);

  return (
    <>
      <AppHeader
        title="Attribution clients ↔ ingénieurs"
        subtitle="Désigner l'ingénieur référent maintenance de chaque client"
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        {/* Récap charge par ingénieur */}
        <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {engineers.map((e) => (
            <Card key={e.id} className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/15 text-xs font-bold text-accent">
                  {e.initials}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{e.fullName}</p>
                  <p className="text-xs text-muted-foreground">
                    {stats[e.id] ?? 0} client{(stats[e.id] ?? 0) > 1 ? "s" : ""} attribué{(stats[e.id] ?? 0) > 1 ? "s" : ""}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Card className="overflow-hidden">
          <div className="border-b p-4">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher un client…"
                className="pl-9"
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Client</th>
                  <th className="px-4 py-3 text-left font-medium">Contact</th>
                  <th className="px-4 py-3 text-left font-medium">Ingénieur référent</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filtered.map((c) => {
                  const ref = engineers.find((e) => e.id === c.assignedEngineerId);
                  return (
                    <tr key={c.id} className="hover:bg-secondary/40">
                      <td className="px-4 py-3">
                        <p className="font-medium">{c.company ?? c.fullName}</p>
                        <p className="text-xs text-muted-foreground">{c.fullName}</p>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">
                        <p>{c.email}</p>
                        {c.phone && <p className="text-xs">{c.phone}</p>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          {ref && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-success/10 px-2 py-0.5 text-xs font-medium text-success ring-1 ring-inset ring-success/30">
                              <UserCheck className="h-3 w-3" /> Attribué
                            </span>
                          )}
                          <Select
                            value={c.assignedEngineerId ?? ""}
                            onValueChange={(v) => handleAssign(c, v)}
                          >
                            <SelectTrigger className="h-8 w-56 text-xs">
                              <SelectValue placeholder="Choisir un ingénieur…" />
                            </SelectTrigger>
                            <SelectContent>
                              {engineers.map((e) => (
                                <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={3} className="p-12 text-center text-sm text-muted-foreground">
                      Aucun client.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </main>
    </>
  );
};

export default AdminAssignments;
