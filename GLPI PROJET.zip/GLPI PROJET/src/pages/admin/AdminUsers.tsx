import { useEffect, useState } from "react";
import { Plus, Trash2, Mail, Shield, Eye, EyeOff } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { usersService } from "@/services/api";
import type { User, UserRole } from "@/types";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const roleLabel: Record<UserRole, string> = {
  client: "Client", engineer: "Ingénieur", commercial: "Commercial", admin: "Super Admin",
};
const roleColor: Record<UserRole, string> = {
  client: "bg-info/10 text-info",
  engineer: "bg-accent/15 text-accent",
  commercial: "bg-success/10 text-success",
  admin: "bg-primary/10 text-primary",
};

const AdminUsers = () => {
  const [list, setList] = useState<User[]>([]);
  const [tab, setTab] = useState<UserRole | "all">("all");
  const [open, setOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [passwordError, setPasswordError] = useState("");

  const load = () => usersService.list().then(setList);
  useEffect(() => { load(); }, []);

  const filtered = tab === "all" ? list : list.filter((u) => u.role === tab);

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const password = String(fd.get("password"));
    const confirm  = String(fd.get("confirmPassword"));

    if (password.length < 8) {
      setPasswordError("Le mot de passe doit contenir au moins 8 caractères.");
      return;
    }
    if (password !== confirm) {
      setPasswordError("Les mots de passe ne correspondent pas.");
      return;
    }
    setPasswordError("");

    await usersService.create({
      email:    String(fd.get("email")),
      fullName: String(fd.get("fullName")),
      role:     fd.get("role") as UserRole,
      company:  String(fd.get("company") ?? "") || undefined,
      phone:    String(fd.get("phone")   ?? "") || undefined,
      // Le mot de passe sera hashé côté Django — ici on l'envoie en clair via HTTPS
      // password: password  ← à décommenter lors du branchement Django
    });

    toast({ title: "Compte créé", description: "L'utilisateur peut maintenant se connecter avec ses identifiants." });
    setOpen(false);
    setShowPassword(false);
    setShowConfirm(false);
    load();
  };

  const handleRemove = async (id: string) => {
    await usersService.remove(id);
    toast({ title: "Utilisateur supprimé" });
    load();
  };

  return (
    <>
      <AppHeader
        title="Utilisateurs"
        subtitle="Clients, ingénieurs, commerciaux, admins"
        actions={
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setPasswordError(""); setShowPassword(false); setShowConfirm(false); } }}>
            <DialogTrigger asChild>
              <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Créer un compte</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Créer un compte utilisateur</DialogTitle>
                <DialogDescription>
                  Le Super Admin définit le rôle et le mot de passe initial. L'utilisateur pourra le modifier depuis son profil.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {/* Nom complet */}
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Nom complet *</Label>
                    <Input id="fullName" name="fullName" required />
                  </div>
                  {/* Rôle */}
                  <div className="space-y-2">
                    <Label htmlFor="role">Rôle *</Label>
                    <Select name="role" defaultValue="engineer">
                      <SelectTrigger id="role"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="client">Client</SelectItem>
                        <SelectItem value="engineer">Ingénieur</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="admin">Super Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Email */}
                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" name="email" type="email" required />
                  </div>
                  {/* Entreprise + Téléphone */}
                  <div className="space-y-2">
                    <Label htmlFor="company">Entreprise</Label>
                    <Input id="company" name="company" placeholder="Pour les clients" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input id="phone" name="phone" type="tel" />
                  </div>
                  {/* Mot de passe */}
                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="password">Mot de passe *</Label>
                    <div className="relative">
                      <Input
                        id="password" name="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Minimum 8 caractères"
                        required
                        onChange={() => setPasswordError("")}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  {/* Confirmer mot de passe */}
                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="confirmPassword">Confirmer le mot de passe *</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword" name="confirmPassword"
                        type={showConfirm ? "text" : "password"}
                        placeholder="Répétez le mot de passe"
                        required
                        onChange={() => setPasswordError("")}
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirm(!showConfirm)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {passwordError && (
                      <p className="text-xs text-destructive">{passwordError}</p>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
                  <Button type="submit" variant="hero">Créer le compte</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="border-b p-4">
            <Tabs value={tab} onValueChange={(v) => setTab(v as UserRole | "all")}>
              <TabsList>
                <TabsTrigger value="all">Tous</TabsTrigger>
                <TabsTrigger value="client">Clients</TabsTrigger>
                <TabsTrigger value="engineer">Ingénieurs</TabsTrigger>
                <TabsTrigger value="commercial">Commerciaux</TabsTrigger>
                <TabsTrigger value="admin">Admins</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Utilisateur</th>
                  <th className="px-4 py-3 text-left font-medium">Email</th>
                  <th className="px-4 py-3 text-left font-medium">Rôle</th>
                  <th className="px-4 py-3 text-left font-medium">Entreprise</th>
                  <th className="px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filtered.map((u) => (
                  <tr key={u.id} className="hover:bg-secondary/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                          {u.initials}
                        </div>
                        <div>
                          <p className="font-medium">{u.fullName}</p>
                          {u.phone && <p className="text-xs text-muted-foreground">{u.phone}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      <span className="inline-flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> {u.email}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn("inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium", roleColor[u.role])}>
                        <Shield className="h-3 w-3" /> {roleLabel[u.role]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{u.company ?? "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleRemove(u.id)} aria-label="Supprimer">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={5} className="p-8 text-center text-sm text-muted-foreground">Aucun utilisateur.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </main>
    </>
  );
};

export default AdminUsers;
