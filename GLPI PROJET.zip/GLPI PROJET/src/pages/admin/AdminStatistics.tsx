import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { ticketsService, maintenancesService, usersService } from "@/services/api";
import type { Maintenance, Ticket, User } from "@/types";
import { slaInfo } from "@/lib/format";

const AdminStatistics = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);

  useEffect(() => {
    ticketsService.list().then(setTickets);
    maintenancesService.list().then(setMaintenances);
    usersService.byRole("engineer").then(setEngineers);
  }, []);

  const stats = engineers.map((e) => {
    const eTickets = tickets.filter((t) => t.assigneeId === e.id);
    const resolved = eTickets.filter((t) => ["resolu", "ferme"].includes(t.status));
    const breached = eTickets.filter((t) => slaInfo(t.slaDueAt).breached && !["resolu", "ferme"].includes(t.status));
    const eMaint = maintenances.filter((m) => m.engineerId === e.id);
    const mDone = eMaint.filter((m) => m.status === "realisee");
    const mPlanned = eMaint.filter((m) => m.status === "planifiee" || m.status === "en_cours");
    // CDC : "maintenances restantes" = planifiées + en cours (non encore réalisées)
    const mRemaining = mPlanned.length;
    const slaRate = eTickets.length
      ? Math.round(((eTickets.length - breached.length) / eTickets.length) * 100)
      : 100;
    return {
      engineer: e,
      total: eTickets.length,
      resolus: resolved.length,
      breached: breached.length,
      slaRate,
      maintenances: eMaint.length,
      mDone: mDone.length,
      mPlanned: mPlanned.length,
      mRemaining,
    };
  });

  const chartData = stats.map((s) => ({
    name: s.engineer.fullName.split(" ")[0],
    "Tickets résolus": s.resolus,
    "Maintenances réalisées": s.mDone,
    "Maintenances restantes": s.mRemaining,
    "SLA dépassés": s.breached,
  }));

  return (
    <>
      <AppHeader title="Statistiques" subtitle="Performance détaillée par ingénieur" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in space-y-6">

        {/* Graphique comparatif */}
        <Card className="p-5">
          <h3 className="text-sm font-semibold">Vue comparative</h3>
          <div className="mt-3 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" />
                <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="Tickets résolus" fill="hsl(152 65% 38%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Maintenances réalisées" fill="hsl(32 96% 50%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Maintenances restantes" fill="hsl(210 90% 50%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="SLA dépassés" fill="hsl(0 78% 55%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Légende manuelle */}
          <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{background:"hsl(152 65% 38%)"}}></span>Tickets résolus</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{background:"hsl(32 96% 50%)"}}></span>Maintenances réalisées</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{background:"hsl(210 90% 50%)"}}></span>Maintenances restantes</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{background:"hsl(0 78% 55%)"}}></span>SLA dépassés</span>
          </div>
        </Card>

        {/* Tableau détaillé par ingénieur */}
        <Card className="overflow-hidden">
          <div className="border-b p-5">
            <h3 className="text-sm font-semibold">Détail par ingénieur</h3>
            <p className="text-xs text-muted-foreground mt-0.5">SLA, tickets résolus, maintenances effectuées, planifiées et restantes</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Ingénieur</th>
                  <th className="px-4 py-3 text-right font-medium">Tickets</th>
                  <th className="px-4 py-3 text-right font-medium">Résolus</th>
                  <th className="px-4 py-3 text-right font-medium">SLA</th>
                  <th className="px-4 py-3 text-right font-medium">Maint. réalisées</th>
                  <th className="px-4 py-3 text-right font-medium">Maint. planifiées</th>
                  <th className="px-4 py-3 text-right font-medium">Maint. restantes</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {stats.map((s) => (
                  <tr key={s.engineer.id} className="hover:bg-secondary/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                          {s.engineer.initials}
                        </div>
                        <div>
                          <p className="font-medium">{s.engineer.fullName}</p>
                          <p className="text-xs text-muted-foreground">{s.engineer.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-mono">{s.total}</td>
                    <td className="px-4 py-3 text-right font-mono text-success">{s.resolus}</td>
                    <td className="px-4 py-3 text-right">
                      <span className={`font-semibold ${s.slaRate >= 95 ? "text-success" : s.slaRate >= 85 ? "text-warning-foreground" : "text-destructive"}`}>
                        {s.slaRate}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono">{s.mDone}</td>
                    <td className="px-4 py-3 text-right font-mono text-info">{s.mPlanned}</td>
                    <td className="px-4 py-3 text-right">
                      <span className={`font-mono font-semibold ${s.mRemaining > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}>
                        {s.mRemaining}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

      </main>
    </>
  );
};

export default AdminStatistics;
