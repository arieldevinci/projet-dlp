import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Users, Ticket as TicketIcon, FileSignature, Wrench, AlertTriangle, ArrowRight } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { contractsService, maintenancesService, ticketsService, usersService } from "@/services/api";
import type { Contract, Maintenance, Ticket, User } from "@/types";
import { slaInfo } from "@/lib/format";

const AdminDashboard = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);

  useEffect(() => {
    ticketsService.list().then(setTickets);
    maintenancesService.list().then(setMaintenances);
    contractsService.list().then(setContracts);
    usersService.byRole("engineer").then(setEngineers);
  }, []);

  const open = tickets.filter((t) => !["resolu", "ferme"].includes(t.status));
  const breached = open.filter((t) => slaInfo(t.slaDueAt).breached);
  const slaRate = tickets.length ? Math.round(((tickets.length - breached.length) / tickets.length) * 100) : 100;

  // Performance par ingénieur
  const perEngineer = engineers.map((e) => {
    const eTickets = tickets.filter((t) => t.assigneeId === e.id);
    const eResolved = eTickets.filter((t) => ["resolu", "ferme"].includes(t.status));
    const eMaintenances = maintenances.filter((m) => m.engineerId === e.id);
    return {
      name: e.fullName.split(" ")[0],
      tickets: eTickets.length,
      resolus: eResolved.length,
      maintenances: eMaintenances.length,
    };
  });

  const breakdown = [
    { name: "Ouverts", value: tickets.filter((t) => t.status === "ouvert").length, color: "hsl(210 90% 50%)" },
    { name: "En cours", value: tickets.filter((t) => t.status === "en_cours").length, color: "hsl(32 96% 50%)" },
    { name: "En attente", value: tickets.filter((t) => t.status === "en_attente").length, color: "hsl(38 95% 52%)" },
    { name: "Résolus", value: tickets.filter((t) => ["resolu", "ferme"].includes(t.status)).length, color: "hsl(152 65% 38%)" },
  ].filter((b) => b.value > 0);

  return (
    <>
      <AppHeader title="Tableau de bord" subtitle="Vue Super Admin · Pilotage global UPSILON" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Tickets ouverts" value={open.length} icon={TicketIcon} accent="info" />
          <KpiCard label="SLA respecté" value={`${slaRate}%`} icon={Wrench} accent="success" />
          <KpiCard label="SLA dépassés" value={breached.length} icon={AlertTriangle} accent="destructive" />
          <KpiCard label="Contrats actifs" value={contracts.filter((c) => c.status === "actif").length} icon={FileSignature} accent="accent" />
        </section>

        <section className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2 p-5">
            <h3 className="text-sm font-semibold">Performance par ingénieur</h3>
            <p className="text-xs text-muted-foreground">Tickets traités vs maintenances</p>
            <div className="mt-3 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={perEngineer} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="resolus" name="Tickets résolus" fill="hsl(152 65% 38%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="maintenances" name="Maintenances" fill="hsl(32 96% 50%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="text-sm font-semibold">Répartition tickets</h3>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={breakdown} dataKey="value" innerRadius={50} outerRadius={75} paddingAngle={3} stroke="hsl(var(--card))" strokeWidth={3}>
                    {breakdown.map((s) => <Cell key={s.name} fill={s.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-3">
          <Card className="p-5">
            <Users className="h-5 w-5 text-accent" />
            <p className="mt-3 text-2xl font-bold">{engineers.length}</p>
            <p className="text-xs text-muted-foreground">Ingénieurs actifs</p>
            <Button variant="ghost" size="sm" className="mt-3 -ml-2" asChild>
              <Link to="/admin/utilisateurs">Gérer <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </Card>
          <Card className="p-5">
            <Wrench className="h-5 w-5 text-info" />
            <p className="mt-3 text-2xl font-bold">{maintenances.filter((m) => m.status === "planifiee").length}</p>
            <p className="text-xs text-muted-foreground">Maintenances planifiées</p>
            <Button variant="ghost" size="sm" className="mt-3 -ml-2" asChild>
              <Link to="/admin/maintenance">Voir <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </Card>
          <Card className="p-5">
            <AlertTriangle className="h-5 w-5 text-warning-foreground" />
            <p className="mt-3 text-2xl font-bold">{tickets.filter((t) => t.escalated).length}</p>
            <p className="text-xs text-muted-foreground">Tickets escaladés</p>
            <Button variant="ghost" size="sm" className="mt-3 -ml-2" asChild>
              <Link to="/admin/tickets">Traiter <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </Card>
        </section>
      </main>
    </>
  );
};

export default AdminDashboard;
