import { useEffect, useState } from "react";
import { Search } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PriorityBadge, StatusBadge } from "@/components/tickets/StatusBadge";
import { ticketsService, usersService } from "@/services/api";
import type { Ticket, User } from "@/types";
import { Link } from "react-router-dom";
import { fmtRelative, slaInfo } from "@/lib/format";
import { toast } from "@/hooks/use-toast";

const AdminTickets = () => {
  const [list, setList] = useState<Ticket[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [query, setQuery] = useState("");

  const load = () => ticketsService.list().then(setList);
  useEffect(() => {
    load();
    usersService.byRole("engineer").then(setEngineers);
  }, []);

  const filtered = list.filter(
    (t) =>
      t.subject.toLowerCase().includes(query.toLowerCase()) ||
      t.clientName.toLowerCase().includes(query.toLowerCase()) ||
      t.reference.toLowerCase().includes(query.toLowerCase()),
  );

  const handleAssign = async (ticket: Ticket, engineerId: string) => {
    const eng = engineers.find((e) => e.id === engineerId);
    if (!eng) return;
    await ticketsService.update(ticket.id, {
      assigneeId: eng.id,
      assigneeName: eng.fullName,
      assigneeInitials: eng.initials,
      status: ticket.status === "ouvert" ? "en_cours" : ticket.status,
    });
    toast({ title: "Ticket assigné", description: `À ${eng.fullName}` });
    load();
  };

  return (
    <>
      <AppHeader title="Tous les tickets" subtitle="Attribution et supervision globale" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="border-b p-4">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher…" className="pl-9" />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Ticket</th>
                  <th className="px-4 py-3 text-left font-medium">Client</th>
                  <th className="px-4 py-3 text-left font-medium">Statut</th>
                  <th className="px-4 py-3 text-left font-medium">Priorité</th>
                  <th className="px-4 py-3 text-left font-medium">SLA</th>
                  <th className="px-4 py-3 text-left font-medium">Assigner à</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filtered.map((t) => {
                  const sla = slaInfo(t.slaDueAt);
                  return (
                    <tr key={t.id} className="hover:bg-secondary/40">
                      <td className="px-4 py-3">
                        <Link to={`/mes-tickets/${t.id}`} className="block">
                          <span className="font-mono text-xs text-muted-foreground">{t.reference}</span>
                          <p className="font-medium hover:text-accent">{t.subject}</p>
                          <p className="text-xs text-muted-foreground">{t.equipmentSerial} · {fmtRelative(t.createdAt)}</p>
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{t.clientName}</td>
                      <td className="px-4 py-3"><StatusBadge status={t.status} /></td>
                      <td className="px-4 py-3"><PriorityBadge priority={t.priority} /></td>
                      <td className="px-4 py-3">
                        {!["resolu", "ferme"].includes(t.status) && (
                          <span className={`text-xs font-medium ${sla.tone}`}>{sla.text}</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <Select value={t.assigneeId ?? ""} onValueChange={(v) => handleAssign(t, v)}>
                          <SelectTrigger className="h-8 w-44 text-xs">
                            <SelectValue placeholder="Assigner…" />
                          </SelectTrigger>
                          <SelectContent>
                            {engineers.map((e) => (
                              <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </main>
    </>
  );
};

export default AdminTickets;
