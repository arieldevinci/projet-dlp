import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, ArrowDownCircle, RefreshCcw } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PriorityBadge, StatusBadge } from "@/components/tickets/StatusBadge";
import { ticketsService, usersService } from "@/services/api";
import type { Ticket, User } from "@/types";
import { fmtRelative, slaInfo } from "@/lib/format";
import { toast } from "@/hooks/use-toast";

/**
 * Vue Super Admin — Gestion des escalades (cf. cahier de charge :
 * « Tickets : attribution des tickets aux ingénieurs, gestion des escalades. »)
 *
 * Liste tous les tickets escaladés et permet :
 *  - de réassigner à un autre ingénieur,
 *  - de désescalader (retour priorité haute) après prise en charge.
 */
const AdminEscalations = () => {
  const [list, setList] = useState<Ticket[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);

  const load = () => ticketsService.list().then((all) => setList(all.filter((t) => t.escalated)));

  useEffect(() => {
    load();
    usersService.byRole("engineer").then(setEngineers);
  }, []);

  const handleReassign = async (t: Ticket, engineerId: string) => {
    const eng = engineers.find((e) => e.id === engineerId);
    if (!eng) return;
    await ticketsService.update(t.id, {
      assigneeId: eng.id,
      assigneeName: eng.fullName,
      assigneeInitials: eng.initials,
      status: "en_cours",
    });
    toast({ title: "Ticket réassigné", description: `Pris en charge par ${eng.fullName}.` });
    load();
  };

  const handleDeescalate = async (t: Ticket) => {
    await ticketsService.update(t.id, { escalated: false, priority: "haute" });
    toast({ title: "Escalade levée", description: `${t.reference} repassé en priorité haute.` });
    load();
  };

  return (
    <>
      <AppHeader
        title="Escalades"
        subtitle="Tickets escaladés nécessitant une décision"
        actions={
          <Button variant="ghost" size="sm" onClick={load}>
            <RefreshCcw className="h-4 w-4" /> Rafraîchir
          </Button>
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        {list.length === 0 ? (
          <Card className="p-12 text-center">
            <AlertTriangle className="mx-auto h-10 w-10 text-muted-foreground/50" />
            <p className="mt-3 text-sm text-muted-foreground">
              Aucune escalade en cours. Tout est sous contrôle.
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {list.map((t) => {
              const sla = slaInfo(t.slaDueAt);
              return (
                <Card key={t.id} className="p-5">
                  <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">{t.reference}</span>
                        <PriorityBadge priority={t.priority} />
                        <StatusBadge status={t.status} />
                        <span className="inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
                          <AlertTriangle className="h-3 w-3" /> Escaladé
                        </span>
                      </div>
                      <Link to={`/mes-tickets/${t.id}`} className="mt-2 block font-medium hover:text-accent">
                        {t.subject}
                      </Link>
                      <p className="text-xs text-muted-foreground">
                        {t.clientName} · {t.equipmentSerial} · ouvert {fmtRelative(t.createdAt)}
                      </p>
                      <p className={`mt-1 text-xs font-medium ${sla.tone}`}>SLA : {sla.text}</p>
                    </div>
                    <div className="flex flex-col gap-2 md:w-72">
                      <Select value={t.assigneeId ?? ""} onValueChange={(v) => handleReassign(t, v)}>
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Réassigner à un ingénieur…" />
                        </SelectTrigger>
                        <SelectContent>
                          {engineers.map((e) => (
                            <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="sm" onClick={() => handleDeescalate(t)}>
                        <ArrowDownCircle className="h-4 w-4" /> Lever l'escalade
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </>
  );
};

export default AdminEscalations;
