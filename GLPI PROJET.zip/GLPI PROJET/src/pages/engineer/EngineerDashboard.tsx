import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Ticket as TicketIcon, AlertTriangle, CheckCircle2, Clock, Wrench, ArrowRight, FileSignature } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { PriorityBadge, StatusBadge } from "@/components/tickets/StatusBadge";
import { useAuth } from "@/contexts/AuthContext";
import { contractsService, maintenancesService, ticketsService } from "@/services/api";
import type { Contract, Maintenance, Ticket } from "@/types";
import { fmtDate, fmtDateTime, slaInfo } from "@/lib/format";
import { cn } from "@/lib/utils";

const contractStatusConfig: Record<Contract["status"], { label: string; classes: string }> = {
  actif: { label: "Actif", classes: "bg-success/10 text-success ring-success/30" },
  expire_bientot: { label: "Expire bientôt", classes: "bg-warning/15 text-warning-foreground ring-warning/40" },
  expire: { label: "Expiré", classes: "bg-destructive/10 text-destructive ring-destructive/30" },
  renouvele: { label: "Renouvelé", classes: "bg-info/10 text-info ring-info/30" },
};

const EngineerDashboard = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);

  useEffect(() => {
    if (!user) return;
    ticketsService.byEngineer(user.id).then(setTickets);
    maintenancesService.byEngineer(user.id).then(setMaintenances);
    // Contrats assignés : on récupère tous les contrats liés aux clients de cet ingénieur
    contractsService.byEngineer(user.id).then(setContracts);
  }, [user]);

  const open = tickets.filter((t) => !["resolu", "ferme"].includes(t.status));
  const breached = open.filter((t) => slaInfo(t.slaDueAt).breached);
  const resolved = tickets.filter((t) => ["resolu", "ferme"].includes(t.status));
  const upcoming = maintenances.filter((m) => m.status === "planifiee" || m.status === "en_cours");

  const byPriority = [
    { name: "Critique", value: open.filter((t) => t.priority === "critique").length, fill: "hsl(0 78% 55%)" },
    { name: "Haute", value: open.filter((t) => t.priority === "haute").length, fill: "hsl(32 96% 50%)" },
    { name: "Moyenne", value: open.filter((t) => t.priority === "moyenne").length, fill: "hsl(210 90% 50%)" },
    { name: "Faible", value: open.filter((t) => t.priority === "faible").length, fill: "hsl(220 15% 65%)" },
  ];

  return (
    <>
      <AppHeader title={`Bonjour ${user?.fullName.split(" ")[0]}`} subtitle="Espace ingénieur · Vos tickets et interventions" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">

        {/* KPI */}
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Tickets ouverts" value={open.length} icon={TicketIcon} accent="info" />
          <KpiCard label="SLA dépassés" value={breached.length} icon={AlertTriangle} accent="destructive" />
          <KpiCard label="Résolus" value={resolved.length} icon={CheckCircle2} accent="success" />
          <KpiCard label="Maintenances à venir" value={upcoming.length} icon={Clock} accent="accent" />
        </section>

        {/* Graphique criticité + Prochaines interventions */}
        <section className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2 p-5">
            <h3 className="text-sm font-semibold">Tickets ouverts par criticité</h3>
            <div className="mt-3 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={byPriority} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Prochaines interventions</h3>
              <Wrench className="h-4 w-4 text-muted-foreground" />
            </div>
            <ul className="mt-3 space-y-3">
              {upcoming.slice(0, 4).map((m) => (
                <li key={m.id} className="flex items-start gap-3">
                  <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${m.type === "preventive" ? "bg-info/10 text-info" : "bg-accent/15 text-accent"}`}>
                    <Wrench className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{m.clientName}</p>
                    <p className="text-xs text-muted-foreground">
                      {m.equipmentSerial} · {fmtDateTime(m.scheduledAt)}
                    </p>
                  </div>
                </li>
              ))}
              {upcoming.length === 0 && <li className="text-xs text-muted-foreground">Aucune intervention planifiée.</li>}
            </ul>
          </Card>
        </section>

        {/* Contrats assignés — CDC : "contrats assignés" dans le dashboard ingénieur */}
        <section className="mt-6">
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b p-5">
              <div>
                <h3 className="text-sm font-semibold">Contrats assignés</h3>
                <p className="text-xs text-muted-foreground">Contrats actifs sur votre périmètre client</p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/ing/contrats">Tout voir <ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
            <ul className="divide-y">
              {contracts.slice(0, 4).map((c) => {
                const cfg = contractStatusConfig[c.status];
                const daysLeft = Math.ceil((new Date(c.endDate).getTime() - Date.now()) / (1000 * 3600 * 24));
                return (
                  <li key={c.id} className="flex items-center gap-4 p-4">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/5 text-primary">
                      <FileSignature className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">{c.reference}</span>
                        <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", cfg.classes)}>
                          {cfg.label}
                        </span>
                      </div>
                      <p className="mt-0.5 text-sm font-medium">{c.clientName}</p>
                      <p className="text-xs text-muted-foreground">
                        Validité : {fmtDate(c.startDate)} → {fmtDate(c.endDate)}
                        {c.status === "actif" && daysLeft > 0 && (
                          <span className={daysLeft < 60 ? " · text-warning-foreground font-medium" : " · "}>
                            {daysLeft}j restants
                          </span>
                        )}
                      </p>
                    </div>
                  </li>
                );
              })}
              {contracts.length === 0 && (
                <li className="p-8 text-center text-sm text-muted-foreground">Aucun contrat assigné.</li>
              )}
            </ul>
          </Card>
        </section>

        {/* Tickets prioritaires */}
        <section className="mt-6">
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b p-5">
              <div>
                <h3 className="text-sm font-semibold">Mes tickets prioritaires</h3>
                <p className="text-xs text-muted-foreground">Triés par SLA le plus serré</p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/ing/tickets">Tout voir <ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
            <ul className="divide-y">
              {open.slice(0, 5).map((t) => {
                const sla = slaInfo(t.slaDueAt);
                return (
                  <li key={t.id}>
                    <Link to={`/mes-tickets/${t.id}`} className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary/50">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{t.reference}</span>
                          <PriorityBadge priority={t.priority} />
                        </div>
                        <p className="truncate text-sm font-medium">{t.subject}</p>
                        <p className="truncate text-xs text-muted-foreground">{t.clientName} · {t.equipmentSerial}</p>
                      </div>
                      <div className="hidden md:flex flex-col items-end gap-1">
                        <StatusBadge status={t.status} />
                        <span className={`text-[11px] font-medium ${sla.tone}`}>{sla.text}</span>
                      </div>
                    </Link>
                  </li>
                );
              })}
              {open.length === 0 && (
                <li className="p-8 text-center text-sm text-muted-foreground">Aucun ticket ouvert. Bravo !</li>
              )}
            </ul>
          </Card>
        </section>

      </main>
    </>
  );
};

export default EngineerDashboard;
