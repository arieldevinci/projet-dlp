import { useEffect, useState } from "react";
import { Calendar, Plus, Wrench, Upload, FileText, CheckCircle2, Edit2 } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { equipmentsService, maintenancesService, usersService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Equipment, Maintenance, MaintenanceStatus, User } from "@/types";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const statusConfig: Record<MaintenanceStatus, { label: string; classes: string }> = {
  planifiee: { label: "Planifiée", classes: "bg-info/10 text-info ring-info/30" },
  en_cours: { label: "En cours", classes: "bg-accent/15 text-accent ring-accent/30" },
  realisee: { label: "Réalisée", classes: "bg-success/10 text-success ring-success/30" },
  annulee: { label: "Annulée", classes: "bg-muted text-muted-foreground ring-border" },
};

const TABS: { value: MaintenanceStatus | "all"; label: string }[] = [
  { value: "all", label: "Toutes" },
  { value: "planifiee", label: "Planifiées" },
  { value: "en_cours", label: "En cours" },
  { value: "realisee", label: "Réalisées" },
];

const EngineerMaintenance = () => {
  const { user } = useAuth();
  // Seul l'ingénieur peut planifier et uploader des rapports (CDC)
  // L'admin a accès en lecture seule à cette page
  const canPlan = user?.role === "engineer";

  const [list, setList] = useState<Maintenance[]>([]);
  const [tab, setTab] = useState<MaintenanceStatus | "all">("all");
  const [clients, setClients] = useState<User[]>([]);
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [open, setOpen] = useState(false);
  const [reportOpenId, setReportOpenId] = useState<string | null>(null);
  const [editTarget, setEditTarget] = useState<Maintenance | null>(null);

  const load = () => {
    if (user) maintenancesService.byEngineer(user.id).then(setList);
  };

  useEffect(() => {
    load();
    usersService.byRole("client").then(setClients);
    equipmentsService.list().then(setEquipments);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const filtered = tab === "all" ? list : list.filter((m) => m.status === tab);

  const handlePlan = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    const fd = new FormData(e.currentTarget);
    const equipment = equipments.find((eq) => eq.id === String(fd.get("equipmentId")));
    const client = clients.find((c) => c.id === equipment?.clientId);
    if (!equipment || !client) return;

    await maintenancesService.create({
      type: fd.get("type") as Maintenance["type"],
      status: "planifiee",
      clientId: client.id,
      clientName: client.company ?? client.fullName,
      equipmentId: equipment.id,
      equipmentSerial: equipment.serial,
      engineerId: user.id,
      engineerName: user.fullName,
      scheduledAt: new Date(String(fd.get("scheduledAt"))).toISOString(),
      durationMinutes: Number(fd.get("durationMinutes")),
      notes: String(fd.get("notes") ?? ""),
    });
    toast({ title: "Maintenance planifiée", description: "Le client recevra un email de notification." });
    setOpen(false);
    load();
  };

  const handleUploadReport = async (m: Maintenance, fileName: string) => {
    await maintenancesService.uploadReport(m.id, fileName);
    toast({
      title: "Rapport enregistré",
      description: `${fileName} — un email de validation a été envoyé à ${m.clientName}.`,
    });
    setReportOpenId(null);
    load();
  };

  const handleUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editTarget) return;
    const fd = new FormData(e.currentTarget);
    await maintenancesService.update(editTarget.id, {
      type: fd.get("type") as Maintenance["type"],
      scheduledAt: new Date(String(fd.get("scheduledAt"))).toISOString(),
      durationMinutes: Number(fd.get("durationMinutes")),
      notes: String(fd.get("notes") ?? ""),
    });
    toast({ title: "Maintenance mise à jour" });
    setEditTarget(null);
    load();
  };

  return (
    <>
      <AppHeader
        title="Planning maintenance"
        subtitle={canPlan ? "Préventive, curative, rapports PDF" : "Consultation du planning de maintenance"}
        actions={
          canPlan ? (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Planifier</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Planifier une maintenance</DialogTitle>
                <DialogDescription>Le client sera notifié par email.</DialogDescription>
              </DialogHeader>
              <form onSubmit={handlePlan} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Type *</Label>
                  <Select name="type" defaultValue="preventive">
                    <SelectTrigger id="type"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="preventive">Préventive</SelectItem>
                      <SelectItem value="curative">Curative</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="equipmentId">Équipement (n° de série) *</Label>
                  <Select name="equipmentId" required>
                    <SelectTrigger id="equipmentId"><SelectValue placeholder="Sélectionner…" /></SelectTrigger>
                    <SelectContent>
                      {equipments.map((eq) => (
                        <SelectItem key={eq.id} value={eq.id}>
                          {eq.serial} — {eq.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="scheduledAt">Date & heure *</Label>
                    <Input id="scheduledAt" name="scheduledAt" type="datetime-local" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="durationMinutes">Durée (min)</Label>
                    <Input id="durationMinutes" name="durationMinutes" type="number" defaultValue={60} min={15} step={15} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea id="notes" name="notes" rows={3} placeholder="Procédure, matériel à prévoir…" />
                </div>
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
                  <Button type="submit" variant="hero">Planifier</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          ) : undefined
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="border-b p-4">
            <Tabs value={tab} onValueChange={(v) => setTab(v as MaintenanceStatus | "all")}>
              <TabsList>
                {TABS.map((t) => <TabsTrigger key={t.value} value={t.value}>{t.label}</TabsTrigger>)}
              </TabsList>
            </Tabs>
          </div>
          <ul className="divide-y">
            {filtered.length === 0 && (
              <li className="p-12 text-center text-sm text-muted-foreground">Aucune intervention.</li>
            )}
            {filtered.map((m) => {
              const cfg = statusConfig[m.status];
              return (
                <li key={m.id} className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:gap-4">
                  <div className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                    m.type === "preventive" ? "bg-info/10 text-info" : "bg-accent/15 text-accent",
                  )}>
                    <Wrench className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{m.reference}</span>
                      <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", cfg.classes)}>
                        {cfg.label}
                      </span>
                      <span className="text-xs text-muted-foreground capitalize">{m.type}</span>
                    </div>
                    <p className="mt-1 text-sm font-medium">{m.clientName} · <span className="font-mono text-xs text-muted-foreground">{m.equipmentSerial}</span></p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" /> {fmtDateTime(m.scheduledAt)}</span>
                      <span>{m.durationMinutes} min</span>
                    </div>
                    {m.notes && <p className="mt-2 text-sm text-muted-foreground">{m.notes}</p>}
                    {m.reportPdfName && (
                      <p className="mt-2 inline-flex items-center gap-1 text-xs text-success">
                        <FileText className="h-3 w-3" /> {m.reportPdfName}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col gap-2">
                    {canPlan && m.status !== "realisee" && m.status !== "annulee" && (
                      <Button variant="outline" size="sm" onClick={() => setEditTarget(m)}>
                        <Edit2 className="h-4 w-4" /> Modifier
                      </Button>
                    )}
                    {canPlan && (!m.reportPdfName ? (
                      <Dialog open={reportOpenId === m.id} onOpenChange={(o) => setReportOpenId(o ? m.id : null)}>
                        <DialogTrigger asChild>
                          <Button variant="hero" size="sm"><Upload className="h-4 w-4" /> Uploader rapport</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Rapport d'intervention — {m.reference}</DialogTitle>
                            <DialogDescription>
                              Joignez le PDF de l'intervention. Le client recevra une notification email automatique.
                            </DialogDescription>
                          </DialogHeader>
                          <UploadReportForm onSubmit={(name) => handleUploadReport(m, name)} />
                        </DialogContent>
                      </Dialog>
                    ) : (
                      <Button variant="outline" size="sm" disabled>
                        <CheckCircle2 className="h-4 w-4" /> Rapport envoyé
                      </Button>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      </main>

      {/* Dialog modification maintenance */}
      <Dialog open={!!editTarget} onOpenChange={(o) => { if (!o) setEditTarget(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Modifier la maintenance — {editTarget?.reference}</DialogTitle>
            <DialogDescription>
              {editTarget?.clientName} · <span className="font-mono text-xs">{editTarget?.equipmentSerial}</span>
            </DialogDescription>
          </DialogHeader>
          {editTarget && (
            <form onSubmit={handleUpdate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-type">Type *</Label>
                <Select name="type" defaultValue={editTarget.type}>
                  <SelectTrigger id="edit-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="preventive">Préventive</SelectItem>
                    <SelectItem value="curative">Curative</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="edit-scheduledAt">Date & heure *</Label>
                  <Input
                    id="edit-scheduledAt"
                    name="scheduledAt"
                    type="datetime-local"
                    required
                    defaultValue={editTarget.scheduledAt.slice(0, 16)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-duration">Durée (min)</Label>
                  <Input
                    id="edit-duration"
                    name="durationMinutes"
                    type="number"
                    defaultValue={editTarget.durationMinutes}
                    min={15}
                    step={15}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-notes">Notes</Label>
                <Textarea
                  id="edit-notes"
                  name="notes"
                  rows={3}
                  defaultValue={editTarget.notes ?? ""}
                  placeholder="Procédure, matériel à prévoir…"
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setEditTarget(null)}>Annuler</Button>
                <Button type="submit" variant="hero">Enregistrer</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

const UploadReportForm = ({ onSubmit }: { onSubmit: (fileName: string) => void }) => {
  const [fileName, setFileName] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (fileName) onSubmit(fileName);
      }}
      className="space-y-4"
    >
      <div className="space-y-2">
        <Label htmlFor="report">Fichier PDF *</Label>
        <Input
          id="report"
          type="file"
          accept="application/pdf"
          required
          onChange={(e) => setFileName(e.target.files?.[0]?.name ?? "")}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="comment">Commentaire (facultatif)</Label>
        <Textarea id="comment" rows={3} placeholder="Résumé de l'intervention, recommandations…" />
      </div>
      <DialogFooter>
        <Button type="submit" variant="hero" disabled={!fileName}>Envoyer le rapport</Button>
      </DialogFooter>
    </form>
  );
};

export default EngineerMaintenance;
