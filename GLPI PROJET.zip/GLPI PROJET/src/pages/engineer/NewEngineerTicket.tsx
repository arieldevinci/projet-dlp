import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { equipmentsService, ticketsService, usersService } from "@/services/api";
import { toast } from "@/hooks/use-toast";
import type { Equipment, TicketCategory, TicketPriority, User } from "@/types";

/**
 * Création d'un ticket par un INGÉNIEUR (cf. cahier des charges, vue Ingénieur).
 * L'ingénieur choisit d'abord le CLIENT, puis l'équipement (n° de série) parmi ceux du client.
 */
const NewEngineerTicket = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [clients, setClients] = useState<User[]>([]);
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [clientId, setClientId] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    usersService.byRole("client").then(setClients);
  }, []);

  useEffect(() => {
    if (clientId) equipmentsService.byClient(clientId).then(setEquipments);
    else setEquipments([]);
  }, [clientId]);

  const selectedClient = useMemo(
    () => clients.find((c) => c.id === clientId),
    [clients, clientId],
  );

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !selectedClient) return;
    setSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const equipment = equipments.find((eq) => eq.id === String(fd.get("equipmentId")));
    if (!equipment) {
      toast({ title: "Équipement requis", variant: "destructive" });
      setSubmitting(false);
      return;
    }
    const priority = fd.get("priority") as TicketPriority;
    const slaHours = priority === "critique" ? 4 : priority === "haute" ? 8 : 24;
    const created = await ticketsService.create({
      subject: String(fd.get("subject")),
      description: String(fd.get("description")),
      category: fd.get("category") as TicketCategory,
      priority,
      status: "en_cours",
      clientId: selectedClient.id,
      clientName: selectedClient.company ?? selectedClient.fullName,
      equipmentId: equipment.id,
      equipmentSerial: equipment.serial,
      equipmentLabel: equipment.label,
      contractId: equipment.contractId,
      assigneeId: user.id,
      assigneeName: user.fullName,
      assigneeInitials: user.initials,
      slaDueAt: new Date(Date.now() + slaHours * 3600 * 1000).toISOString(),
    });
    toast({ title: "Ticket créé", description: `${created.reference} ouvert et auto-assigné.` });
    navigate(`/mes-tickets/${created.id}`);
  };

  return (
    <>
      <AppHeader title="Nouveau ticket" subtitle="Création d'un ticket pour un client" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Button>

        <Card className="max-w-3xl p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="clientId">Client *</Label>
                <Select value={clientId} onValueChange={setClientId} required>
                  <SelectTrigger id="clientId"><SelectValue placeholder="Sélectionner un client…" /></SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.company ?? c.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="equipmentId">Équipement (n° de série) *</Label>
                <Select name="equipmentId" required disabled={!clientId}>
                  <SelectTrigger id="equipmentId">
                    <SelectValue placeholder={clientId ? "Sélectionner…" : "Choisir un client d'abord"} />
                  </SelectTrigger>
                  <SelectContent>
                    {equipments.map((eq) => (
                      <SelectItem key={eq.id} value={eq.id}>
                        {eq.serial} — {eq.label}
                      </SelectItem>
                    ))}
                    {clientId && equipments.length === 0 && (
                      <SelectItem value="none" disabled>Aucun équipement pour ce client</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject">Sujet *</Label>
              <Input id="subject" name="subject" required placeholder="Ex : Onduleur HS après coupure secteur" />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="category">Catégorie *</Label>
                <Select name="category" defaultValue="incident">
                  <SelectTrigger id="category"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="incident">Incident</SelectItem>
                    <SelectItem value="demande">Demande d'assistance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priorité *</Label>
                <Select name="priority" defaultValue="moyenne">
                  <SelectTrigger id="priority"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="faible">Faible</SelectItem>
                    <SelectItem value="moyenne">Moyenne</SelectItem>
                    <SelectItem value="haute">Haute</SelectItem>
                    <SelectItem value="critique">Critique</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description détaillée *</Label>
              <Textarea
                id="description"
                name="description"
                required
                rows={6}
                placeholder="Décrivez le problème observé, le contexte, les actions déjà entreprises…"
              />
            </div>

            <div className="flex items-center justify-end gap-3 border-t pt-5">
              <Button type="button" variant="ghost" onClick={() => navigate(-1)}>Annuler</Button>
              <Button type="submit" variant="hero" disabled={submitting || !clientId}>
                {submitting ? "Création…" : "Créer le ticket"}
              </Button>
            </div>
          </form>
        </Card>
      </main>
    </>
  );
};

export default NewEngineerTicket;
