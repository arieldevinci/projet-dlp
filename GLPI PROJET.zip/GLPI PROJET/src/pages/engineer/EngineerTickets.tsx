import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Search, ChevronRight, Plus } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PriorityBadge, StatusBadge, type TicketStatus } from "@/components/tickets/StatusBadge";
import { ticketsService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Ticket } from "@/types";
import { fmtRelative, slaInfo } from "@/lib/format";

const TABS: { value: TicketStatus | "all"; label: string }[] = [
  { value: "all", label: "Tous" },
  { value: "ouvert", label: "Ouverts" },
  { value: "en_cours", label: "En cours" },
  { value: "en_attente", label: "En attente" },
  { value: "resolu", label: "Résolus" },
];

const EngineerTickets = () => {
  const { user } = useAuth();
  const [list, setList] = useState<Ticket[]>([]);
  const [tab, setTab] = useState<TicketStatus | "all">("all");
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (user) ticketsService.byEngineer(user.id).then(setList);
  }, [user]);

  const filtered = useMemo(() => {
    return list.filter((t) => {
      const matchTab = tab === "all" || t.status === tab;
      const q = query.toLowerCase().trim();
      const matchQuery =
        !q ||
        t.subject.toLowerCase().includes(q) ||
        t.clientName.toLowerCase().includes(q) ||
        t.equipmentSerial.toLowerCase().includes(q) ||
        t.reference.toLowerCase().includes(q);
      return matchTab && matchQuery;
    });
  }, [list, tab, query]);

  return (
    <>
      <AppHeader
        title="Mes tickets assignés"
        subtitle="Tous les tickets dont vous êtes responsable"
        actions={
          <Button variant="hero" size="sm" asChild>
            <Link to="/ing/tickets/nouveau"><Plus className="h-4 w-4" /> Nouveau ticket</Link>
          </Button>
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="flex flex-col gap-3 border-b p-4 md:flex-row md:items-center md:justify-between">
            <Tabs value={tab} onValueChange={(v) => setTab(v as TicketStatus | "all")}>
              <TabsList>
                {TABS.map((t) => <TabsTrigger key={t.value} value={t.value}>{t.label}</TabsTrigger>)}
              </TabsList>
            </Tabs>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher…"
                className="w-full pl-9 md:w-72"
              />
            </div>
          </div>
          <ul className="divide-y">
            {filtered.map((t) => {
              const sla = slaInfo(t.slaDueAt);
              return (
                <li key={t.id}>
                  <Link to={`/mes-tickets/${t.id}`} className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary/50">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">{t.reference}</span>
                        <PriorityBadge priority={t.priority} />
                        <StatusBadge status={t.status} />
                      </div>
                      <p className="mt-1 font-medium">{t.subject}</p>
                      <p className="text-xs text-muted-foreground">
                        {t.clientName} · {t.equipmentSerial} · {fmtRelative(t.createdAt)}
                      </p>
                    </div>
                    <div className="hidden md:flex flex-col items-end gap-1">
                      {!["resolu", "ferme"].includes(t.status) && (
                        <span className={`text-xs font-medium ${sla.tone}`}>{sla.text}</span>
                      )}
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </Link>
                </li>
              );
            })}
            {filtered.length === 0 && (
              <li className="p-12 text-center text-sm text-muted-foreground">Aucun ticket.</li>
            )}
          </ul>
        </Card>
      </main>
    </>
  );
};

export default EngineerTickets;
