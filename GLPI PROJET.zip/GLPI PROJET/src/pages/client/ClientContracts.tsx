import { useEffect, useState } from "react";
import { Calendar, FileSignature, RefreshCw } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { contractsService, equipmentsService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Contract, Equipment } from "@/types";
import { fmtDate } from "@/lib/format";
import { cn } from "@/lib/utils";

const statusConfig = {
  actif: { label: "Actif", classes: "bg-success/10 text-success ring-success/30" },
  expire_bientot: { label: "Expire bientôt", classes: "bg-warning/15 text-warning-foreground ring-warning/40" },
  expire: { label: "Expiré", classes: "bg-destructive/10 text-destructive ring-destructive/30" },
  renouvele: { label: "Renouvelé", classes: "bg-info/10 text-info ring-info/30" },
};

const ClientContracts = () => {
  const { user } = useAuth();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [equipments, setEquipments] = useState<Equipment[]>([]);

  useEffect(() => {
    if (!user) return;
    contractsService.byClient(user.id).then(setContracts);
    equipmentsService.byClient(user.id).then(setEquipments);
  }, [user]);

  const equipmentsById = Object.fromEntries(equipments.map((e) => [e.id, e]));

  return (
    <>
      <AppHeader title="Mes contrats" subtitle="Couverture, périmètre et dates de validité" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        {contracts.length === 0 && (
          <Card className="p-8 text-center text-sm text-muted-foreground">Aucun contrat.</Card>
        )}
        <div className="grid gap-4">
          {contracts.map((c) => {
            const cfg = statusConfig[c.status];
            const daysLeft = Math.ceil((new Date(c.endDate).getTime() - Date.now()) / (1000 * 3600 * 24));
            return (
              <Card key={c.id} className="overflow-hidden">
                <div className="flex flex-col gap-4 p-6 md:flex-row md:items-start md:justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <FileSignature className="h-5 w-5 text-accent" />
                      <h3 className="text-lg font-semibold">{c.reference}</h3>
                      <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset", cfg.classes)}>
                        {cfg.label}
                      </span>
                    </div>
                    <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{c.scope}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5" />
                        Du {fmtDate(c.startDate)} au {fmtDate(c.endDate)}
                      </span>
                      {c.status !== "expire" && c.status !== "renouvele" && (
                        <span className={daysLeft < 60 ? "text-warning-foreground font-medium" : ""}>
                          {daysLeft > 0 ? `${daysLeft} jours restants` : "Expiré"}
                        </span>
                      )}
                    </div>
                  </div>
                  {c.status === "expire_bientot" && (
                    <Button variant="hero" size="sm">
                      <RefreshCw className="h-4 w-4" /> Demander renouvellement
                    </Button>
                  )}
                </div>

                {c.equipmentIds.length > 0 && (
                  <div className="border-t bg-secondary/30 p-5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Périmètre couvert ({c.equipmentIds.length} équipement{c.equipmentIds.length > 1 ? "s" : ""})
                    </h4>
                    <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                      {c.equipmentIds.map((eqId) => {
                        const eq = equipmentsById[eqId];
                        if (!eq) return null;
                        return (
                          <li key={eqId} className="flex items-center justify-between rounded-md bg-background p-2.5">
                            <div className="min-w-0">
                              <p className="truncate text-sm font-medium">{eq.label}</p>
                              <p className="font-mono text-xs text-muted-foreground">{eq.serial}</p>
                            </div>
                            <span className="text-xs text-muted-foreground">Garantie {fmtDate(eq.warrantyEnd)}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </main>
    </>
  );
};

export default ClientContracts;
