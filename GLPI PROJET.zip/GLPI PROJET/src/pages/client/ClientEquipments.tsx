import { useEffect, useState } from "react";
import { Package, Shield } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { equipmentsService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Equipment } from "@/types";
import { fmtDate } from "@/lib/format";

const ClientEquipments = () => {
  const { user } = useAuth();
  const [list, setList] = useState<Equipment[]>([]);

  useEffect(() => {
    if (user) equipmentsService.byClient(user.id).then(setList);
  }, [user]);

  return (
    <>
      <AppHeader title="Mes équipements" subtitle="Parc sous contrat et garanties" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((eq) => {
            const warrantyDays = Math.ceil((new Date(eq.warrantyEnd).getTime() - Date.now()) / (1000 * 3600 * 24));
            const expiringSoon = warrantyDays > 0 && warrantyDays < 90;
            const expired = warrantyDays <= 0;
            return (
              <Card key={eq.id} className="p-5">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/5 text-primary">
                    <Package className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">{eq.label}</p>
                    <p className="font-mono text-xs text-muted-foreground">{eq.serial}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {eq.brand} · {eq.model}
                    </p>
                  </div>
                </div>
                <dl className="mt-4 space-y-1.5 border-t pt-3 text-xs">
                  <div className="flex items-center justify-between">
                    <dt className="text-muted-foreground">Type</dt>
                    <dd className="font-medium">{eq.type}</dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-muted-foreground">Installé le</dt>
                    <dd className="font-medium">{fmtDate(eq.installedAt)}</dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-muted-foreground flex items-center gap-1"><Shield className="h-3 w-3" />Garantie</dt>
                    <dd className={`font-medium ${expired ? "text-destructive" : expiringSoon ? "text-warning-foreground" : ""}`}>
                      {fmtDate(eq.warrantyEnd)}
                    </dd>
                  </div>
                </dl>
              </Card>
            );
          })}
        </div>
      </main>
    </>
  );
};

export default ClientEquipments;
