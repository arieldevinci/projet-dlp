import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { equipmentsService, ticketsService } from "@/services/api";
import { toast } from "@/hooks/use-toast";
import type { Equipment, TicketCategory, TicketPriority } from "@/types";

const NewTicket = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user) equipmentsService.byClient(user.id).then(setEquipments);
  }, [user]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    const fd = new FormData(e.currentTarget);
    const equipment = equipments.find((eq) => eq.id === String(fd.get("equipmentId")));
    if (!equipment) {
      toast({ title: "Équipement requis", variant: "destructive" });
      setSubmitting(false);
      return;
    }
    const slaHours = Number(fd.get("priority")) === 0 ? 4 : 24;
    const created = await ticketsService.create({
      subject: String(fd.get("subject")),
      description: String(fd.get("description")),
      category: fd.get("category") as TicketCategory,
      priority: fd.get("priority") as TicketPriority,
      status: "ouvert",
      clientId: user.id,
      clientName: user.company ?? user.fullName,
      equipmentId: equipment.id,
      equipmentSerial: equipment.serial,
      equipmentLabel: equipment.label,
      contractId: equipment.contractId,
      slaDueAt: new Date(Date.now() + slaHours * 3600 * 1000).toISOString(),
    });
    toast({ title: "Ticket créé", description: `${created.reference} a été ouvert.` });
    navigate(`/mes-tickets/${created.id}`);
  };

  return (
    <>
      <AppHeader title="Nouveau ticket" subtitle="Décrivez votre demande" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Button>

        <Card className="max-w-3xl p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="subject">Sujet *</Label>
              <Input id="subject" name="subject" required placeholder="Ex : Onduleur HS après coupure secteur" />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="equipmentId">Équipement concerné (n° de série) *</Label>
                <Select name="equipmentId" required>
                  <SelectTrigger id="equipmentId"><SelectValue placeholder="Sélectionner…" /></SelectTrigger>
                  <SelectContent>
                    {equipments.map((eq) => (
                      <SelectItem key={eq.id} value={eq.id}>
                        {eq.serial} — {eq.label}
                      </SelectItem>
                    ))}
                    {equipments.length === 0 && (
                      <SelectItem value="none" disabled>Aucun équipement enregistré</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Catégorie *</Label>
                <Select name="category" defaultValue="panne">
                  <SelectTrigger id="category"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="panne">Panne</SelectItem>
                    <SelectItem value="incident">Incident</SelectItem>
                    <SelectItem value="demande">Demande</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="autre">Autre</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priorité *</Label>
              <Select name="priority" defaultValue="moyenne">
                <SelectTrigger id="priority"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="faible">Faible — sans urgence</SelectItem>
                  <SelectItem value="moyenne">Moyenne — gêne fonctionnelle</SelectItem>
                  <SelectItem value="haute">Haute — service dégradé</SelectItem>
                  <SelectItem value="critique">Critique — service indisponible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description détaillée *</Label>
              <Textarea
                id="description"
                name="description"
                required
                rows={6}
                placeholder="Décrivez précisément le problème : symptômes, contexte (heure, action), messages d'erreur, ce qui a déjà été tenté…"
              />
              <p className="text-xs text-muted-foreground">
                Plus votre description est précise, plus l'intervention sera rapide.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 border-t pt-5">
              <Button type="button" variant="ghost" onClick={() => navigate(-1)}>Annuler</Button>
              <Button type="submit" variant="hero" disabled={submitting}>
                {submitting ? "Création…" : "Créer le ticket"}
              </Button>
            </div>
          </form>
        </Card>
      </main>
    </>
  );
};

export default NewTicket;
