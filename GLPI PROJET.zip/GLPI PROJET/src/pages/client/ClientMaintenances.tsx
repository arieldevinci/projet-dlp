import { useEffect, useState } from "react";
import { Calendar, Download, FileText, Wrench } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { maintenancesService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Maintenance, MaintenanceStatus } from "@/types";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const statusConfig: Record<MaintenanceStatus, { label: string; classes: string }> = {
  planifiee: { label: "Planifiée", classes: "bg-info/10 text-info ring-info/30" },
  en_cours: { label: "En cours", classes: "bg-accent/15 text-accent ring-accent/30" },
  realisee: { label: "Réalisée", classes: "bg-success/10 text-success ring-success/30" },
  annulee: { label: "Annulée", classes: "bg-muted text-muted-foreground ring-border" },
};

const TABS: { value: MaintenanceStatus | "all"; label: string }[] = [
  { value: "all", label: "Toutes" },
  { value: "planifiee", label: "Planifiées" },
  { value: "en_cours", label: "En cours" },
  { value: "realisee", label: "Réalisées" },
];

const ClientMaintenances = () => {
  const { user } = useAuth();
  const [list, setList] = useState<Maintenance[]>([]);
  const [tab, setTab] = useState<MaintenanceStatus | "all">("all");

  useEffect(() => {
    if (user) maintenancesService.byClient(user.id).then(setList);
  }, [user]);

  const filtered = tab === "all" ? list : list.filter((m) => m.status === tab);

  return (
    <>
      <AppHeader title="Mes maintenances" subtitle="Préventives et curatives planifiées sur mon parc" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="border-b p-4">
            <Tabs value={tab} onValueChange={(v) => setTab(v as MaintenanceStatus | "all")}>
              <TabsList>
                {TABS.map((t) => <TabsTrigger key={t.value} value={t.value}>{t.label}</TabsTrigger>)}
              </TabsList>
            </Tabs>
          </div>

          <ul className="divide-y">
            {filtered.length === 0 && (
              <li className="p-12 text-center text-sm text-muted-foreground">
                Aucune maintenance.
              </li>
            )}
            {filtered.map((m) => {
              const cfg = statusConfig[m.status];
              return (
                <li key={m.id} className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:gap-4">
                  <div className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                    m.type === "preventive" ? "bg-info/10 text-info" : "bg-accent/15 text-accent",
                  )}>
                    <Wrench className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{m.reference}</span>
                      <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", cfg.classes)}>
                        {cfg.label}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {m.type === "preventive" ? "Préventive" : "Curative"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-medium">{m.equipmentSerial}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5" /> {fmtDateTime(m.scheduledAt)}
                      </span>
                      <span>Durée prévue : {m.durationMinutes} min</span>
                      <span>Ingénieur : {m.engineerName}</span>
                    </div>
                    {m.notes && <p className="mt-2 text-sm text-muted-foreground">{m.notes}</p>}
                  </div>
                  {m.reportPdfName && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toast({ title: "Téléchargement", description: m.reportPdfName })}
                    >
                      <FileText className="h-4 w-4" />
                      Rapport PDF
                      <Download className="h-4 w-4" />
                    </Button>
                  )}
                </li>
              );
            })}
          </ul>
        </Card>
      </main>
    </>
  );
};

export default ClientMaintenances;
