import { useEffect, useState } from "react";
import { Ticket as TicketIcon, CheckCircle2, Clock, AlertTriangle, Plus, ArrowRight, FileSignature, Wrench } from "lucide-react";
import { Link } from "react-router-dom";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { PriorityBadge, StatusBadge } from "@/components/tickets/StatusBadge";
import { useAuth } from "@/contexts/AuthContext";
import { contractsService, maintenancesService, ticketsService } from "@/services/api";
import type { Contract, Maintenance, Ticket } from "@/types";
import { fmtDate, fmtDateTime, slaInfo } from "@/lib/format";

const ClientDashboard = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);

  useEffect(() => {
    if (!user) return;
    ticketsService.byClient(user.id).then(setTickets);
    contractsService.byClient(user.id).then(setContracts);
    maintenancesService.byClient(user.id).then(setMaintenances);
  }, [user]);

  const open = tickets.filter((t) => ["ouvert", "en_cours", "en_attente"].includes(t.status));
  const resolved = tickets.filter((t) => ["resolu", "ferme"].includes(t.status));
  const breached = tickets.filter((t) => slaInfo(t.slaDueAt).breached && !["resolu", "ferme"].includes(t.status));
  const upcomingMnt = maintenances
    .filter((m) => m.status === "planifiee" || m.status === "en_cours")
    .sort((a, b) => +new Date(a.scheduledAt) - +new Date(b.scheduledAt));

  const breakdown = [
    { name: "Ouverts", value: tickets.filter((t) => t.status === "ouvert").length, color: "hsl(210 90% 50%)" },
    { name: "En cours", value: tickets.filter((t) => t.status === "en_cours").length, color: "hsl(32 96% 50%)" },
    { name: "En attente", value: tickets.filter((t) => t.status === "en_attente").length, color: "hsl(38 95% 52%)" },
    { name: "Résolus", value: resolved.length, color: "hsl(152 65% 38%)" },
  ].filter((b) => b.value > 0);

  return (
    <>
      <AppHeader
        title={`Bonjour ${user?.fullName.split(" ")[0]}`}
        subtitle={`Espace client · ${user?.company ?? ""}`}
        actions={
          <Button variant="hero" size="sm" asChild>
            <Link to="/mes-tickets/nouveau">
              <Plus className="h-4 w-4" /> Nouveau ticket
            </Link>
          </Button>
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        {/* Hero */}
        <section className="relative mb-6 overflow-hidden rounded-2xl bg-gradient-hero p-6 md:p-8 text-primary-foreground shadow-elevated">
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-accent/20 blur-3xl" />
          <div className="relative max-w-2xl">
            <p className="text-sm font-medium text-accent-glow">Espace client UPSILON</p>
            <h2 className="mt-2 text-2xl font-bold md:text-3xl">
              {open.length} ticket{open.length > 1 ? "s" : ""} en cours · {upcomingMnt.length} maintenance{upcomingMnt.length > 1 ? "s" : ""} planifiée{upcomingMnt.length > 1 ? "s" : ""}
            </h2>
            <p className="mt-2 text-sm text-primary-foreground/70">
              Suivez en temps réel l'avancement de vos demandes et les interventions à venir sur votre parc.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button variant="hero" size="sm" asChild>
                <Link to="/mes-tickets">
                  Voir mes tickets <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* KPIs */}
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Tickets ouverts" value={open.length} icon={TicketIcon} accent="info" />
          <KpiCard label="Résolus ce mois" value={resolved.length} icon={CheckCircle2} accent="success" />
          <KpiCard label="SLA dépassés" value={breached.length} icon={AlertTriangle} accent="destructive" />
          <KpiCard label="Maintenances à venir" value={upcomingMnt.length} icon={Clock} accent="accent" />
        </section>

        {/* Content */}
        <section className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* Tickets list */}
          <Card className="lg:col-span-2 overflow-hidden">
            <div className="flex items-center justify-between border-b p-5">
              <div>
                <h3 className="text-sm font-semibold">Mes tickets récents</h3>
                <p className="text-xs text-muted-foreground">Demandes en cours et historique</p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/mes-tickets">Tout voir <ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
            {tickets.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                Aucun ticket pour le moment.
              </div>
            ) : (
              <ul className="divide-y">
                {tickets.slice(0, 5).map((t) => {
                  const sla = slaInfo(t.slaDueAt);
                  return (
                    <li key={t.id}>
                      <Link
                        to={`/mes-tickets/${t.id}`}
                        className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary/50"
                      >
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/5 text-primary">
                          <TicketIcon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-muted-foreground">{t.reference}</span>
                            <PriorityBadge priority={t.priority} />
                          </div>
                          <p className="truncate text-sm font-medium">{t.subject}</p>
                          <p className="truncate text-xs text-muted-foreground">{t.equipmentLabel}</p>
                        </div>
                        <div className="hidden md:flex flex-col items-end gap-1">
                          <StatusBadge status={t.status} />
                          {!["resolu", "ferme"].includes(t.status) && (
                            <span className={`text-[11px] font-medium ${sla.tone}`}>{sla.text}</span>
                          )}
                        </div>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          {/* Side */}
          <div className="space-y-4">
            <Card className="p-5">
              <h3 className="text-sm font-semibold">Répartition de mes tickets</h3>
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={breakdown} dataKey="value" innerRadius={45} outerRadius={70} paddingAngle={3} stroke="hsl(var(--card))" strokeWidth={3}>
                      {breakdown.map((s) => <Cell key={s.name} fill={s.color} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="space-y-1.5">
                {breakdown.map((s) => (
                  <li key={s.name} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2 text-muted-foreground">
                      <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                      {s.name}
                    </span>
                    <span className="font-semibold">{s.value}</span>
                  </li>
                ))}
              </ul>
            </Card>

            <Card className="p-5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Mes maintenances</h3>
                <Wrench className="h-4 w-4 text-muted-foreground" />
              </div>
              <ul className="mt-3 space-y-3">
                {upcomingMnt.slice(0, 4).map((m) => (
                  <li key={m.id} className="flex items-start gap-3">
                    <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${m.type === "preventive" ? "bg-info/10 text-info" : "bg-accent/15 text-accent"}`}>
                      <Wrench className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{m.equipmentSerial}</p>
                      <p className="text-xs text-muted-foreground">
                        {m.type === "preventive" ? "Préventive" : "Curative"} · {fmtDateTime(m.scheduledAt)}
                      </p>
                    </div>
                  </li>
                ))}
                {upcomingMnt.length === 0 && (
                  <li className="text-xs text-muted-foreground">Aucune maintenance planifiée.</li>
                )}
              </ul>
            </Card>

            <Card className="p-5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Mes contrats</h3>
                <FileSignature className="h-4 w-4 text-muted-foreground" />
              </div>
              <ul className="mt-3 space-y-3">
                {contracts.slice(0, 3).map((c) => (
                  <li key={c.id} className="text-sm">
                    <p className="font-medium">{c.reference}</p>
                    <p className="text-xs text-muted-foreground">Expire le {fmtDate(c.endDate)}</p>
                  </li>
                ))}
                {contracts.length === 0 && (
                  <li className="text-xs text-muted-foreground">Aucun contrat actif.</li>
                )}
              </ul>
            </Card>
          </div>
        </section>
      </main>
    </>
  );
};

export default ClientDashboard;
