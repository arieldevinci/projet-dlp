import { useEffect, useState } from "react";
import { BookOpen, Eye, Search } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { kbService } from "@/services/api";
import type { KbArticle } from "@/types";

const KbPage = () => {
  const [list, setList] = useState<KbArticle[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    kbService.list().then(setList);
  }, []);

  const filtered = list.filter(
    (a) =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.category.toLowerCase().includes(query.toLowerCase()) ||
      a.excerpt.toLowerCase().includes(query.toLowerCase()),
  );

  const categories = Array.from(new Set(list.map((a) => a.category)));

  return (
    <>
      <AppHeader title="Base de connaissances" subtitle="FAQ et guides d'auto-assistance" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        {/* Hero search */}
        <Card className="relative overflow-hidden p-6 md:p-10">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-accent/10 blur-3xl" />
          <div className="relative max-w-2xl">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-accent text-accent-foreground shadow-glow-accent">
              <BookOpen className="h-6 w-6" />
            </div>
            <h2 className="mt-4 text-2xl font-bold">Comment pouvons-nous vous aider ?</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Trouvez la réponse à vos questions parmi nos guides et procédures.
            </p>
            <div className="relative mt-5">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher un article, une procédure, un équipement…"
                className="pl-9 h-11 text-base"
              />
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setQuery(c)}
                  className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground transition-colors hover:bg-accent/15 hover:text-accent"
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Articles */}
        <section className="mt-6 grid gap-4 md:grid-cols-2">
          {filtered.map((a) => (
            <Card key={a.id} className="cursor-pointer p-5 transition-shadow hover:shadow-soft">
              <p className="text-xs font-medium uppercase tracking-wider text-accent">{a.category}</p>
              <h3 className="mt-1 text-base font-semibold">{a.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{a.excerpt}</p>
              <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {a.views} vues</span>
                <span>·</span>
                <span>Mis à jour {a.updatedAt}</span>
              </div>
            </Card>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full text-center text-sm text-muted-foreground py-8">
              Aucun article ne correspond à votre recherche.
            </p>
          )}
        </section>
      </main>
    </>
  );
};

export default KbPage;
