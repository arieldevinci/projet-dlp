import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Send, Paperclip, AlertTriangle, CheckCircle2, FileText, X } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PriorityBadge, StatusBadge } from "@/components/tickets/StatusBadge";
import { useAuth } from "@/contexts/AuthContext";
import { ticketsService, usersService } from "@/services/api";
import { toast } from "@/hooks/use-toast";
import type { Ticket, User } from "@/types";
import { fmtDateTime, slaInfo } from "@/lib/format";
import { cn } from "@/lib/utils";

const TicketDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [reply, setReply] = useState("");
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [engineers, setEngineers] = useState<User[]>([]);

  useEffect(() => {
    if (id) ticketsService.byId(id).then((t) => setTicket(t ?? null));
  }, [id]);

  useEffect(() => {
    if (user?.role === "admin") usersService.byRole("engineer").then(setEngineers);
  }, [user]);

  if (!ticket || !user) {
    return (
      <>
        <AppHeader title="Ticket" />
        <main className="flex-1 p-8 text-sm text-muted-foreground">Chargement…</main>
      </>
    );
  }

  const sla = slaInfo(ticket.slaDueAt);
  const closed = ["resolu", "ferme"].includes(ticket.status);

  // CDC : l'ingénieur répond, escalade, clôture — l'admin attribue et gère les escalades uniquement
  const isEngineer = user.role === "engineer";
  const isAdmin = user.role === "admin";
  const isClient = user.role === "client";

  const handleSend = async () => {
    if (!reply.trim() && pendingFiles.length === 0) return;
    const attachments = pendingFiles.map((f) => ({
      name: f.name,
      size: `${Math.max(1, Math.round(f.size / 1024))} Ko`,
      url: "#",
    }));
    const updated = await ticketsService.addMessage(ticket.id, {
      authorId: user.id,
      authorName: user.fullName,
      authorRole: user.role,
      authorInitials: user.initials,
      content: reply || (attachments.length ? "Pièce(s) jointe(s) ajoutée(s)." : ""),
      attachments: attachments.length ? attachments : undefined,
    });
    if (updated) {
      setTicket(updated);
      setReply("");
      setPendingFiles([]);
      if (fileInputRef.current) fileInputRef.current.value = "";
      toast({
        title: "Réponse envoyée",
        description: attachments.length ? `${attachments.length} fichier(s) joint(s).` : undefined,
      });
    }
  };

  const handleStatusChange = async (status: Ticket["status"]) => {
    const updated = await ticketsService.update(ticket.id, { status });
    if (updated) {
      setTicket(updated);
      toast({ title: `Ticket ${status === "resolu" ? "marqué résolu" : status === "ferme" ? "fermé" : "mis à jour"}` });
    }
  };

  const handleEscalate = async () => {
    const updated = await ticketsService.update(ticket.id, { escalated: true, priority: "critique" });
    if (updated) {
      setTicket(updated);
      toast({ title: "Ticket escaladé", description: "Priorité passée à critique." });
    }
  };

  // CDC Admin : attribution à un ingénieur
  const handleAssign = async (engineerId: string) => {
    const engineer = engineers.find((e) => e.id === engineerId);
    if (!engineer) return;
    const updated = await ticketsService.update(ticket.id, {
      assigneeId: engineer.id,
      assigneeName: engineer.fullName,
      assigneeInitials: engineer.initials,
    });
    if (updated) {
      setTicket(updated);
      toast({ title: "Ticket attribué", description: `Assigné à ${engineer.fullName}` });
    }
  };

  // CDC Admin : désescalade
  const handleDeescalate = async () => {
    const updated = await ticketsService.update(ticket.id, { escalated: false });
    if (updated) {
      setTicket(updated);
      toast({ title: "Escalade levée" });
    }
  };

  return (
    <>
      <AppHeader title={ticket.reference} subtitle={ticket.subject} />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Button>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Main */}
          <div className="space-y-4 lg:col-span-2">
            <Card className="p-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">{ticket.reference}</span>
                <PriorityBadge priority={ticket.priority} />
                <StatusBadge status={ticket.status} />
                {ticket.escalated && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
                    <AlertTriangle className="h-3 w-3" /> Escaladé
                  </span>
                )}
              </div>
              <h2 className="mt-3 text-xl font-bold">{ticket.subject}</h2>
              <p className="mt-3 whitespace-pre-line text-sm text-muted-foreground">
                {ticket.description}
              </p>
            </Card>

            {/* Conversation */}
            <Card className="overflow-hidden">
              <div className="border-b p-5">
                <h3 className="text-sm font-semibold">Conversation</h3>
                <p className="text-xs text-muted-foreground">
                  {ticket.messages.length} message{ticket.messages.length > 1 ? "s" : ""}
                </p>
              </div>
              <ul className="divide-y">
                {ticket.messages.length === 0 && (
                  <li className="p-8 text-center text-sm text-muted-foreground">
                    Aucun échange pour le moment.
                  </li>
                )}
                {ticket.messages.map((m) => (
                  <li key={m.id} className="flex gap-3 p-4">
                    <div className={cn(
                      "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                      m.authorRole === "client" ? "bg-info/10 text-info" : "bg-accent/15 text-accent",
                    )}>
                      {m.authorInitials}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{m.authorName}</span>
                        <span className="text-xs text-muted-foreground capitalize">· {m.authorRole}</span>
                        <span className="ml-auto text-xs text-muted-foreground">{fmtDateTime(m.createdAt)}</span>
                      </div>
                      <p className="mt-1 whitespace-pre-line text-sm">{m.content}</p>
                      {m.attachments && m.attachments.length > 0 && (
                        <ul className="mt-2 space-y-1">
                          {m.attachments.map((a, i) => (
                            <li key={i}>
                              <a
                                href={a.url}
                                className="inline-flex items-center gap-2 rounded-md border bg-secondary/40 px-2.5 py-1.5 text-xs hover:bg-secondary"
                              >
                                <FileText className="h-3.5 w-3.5 text-accent" />
                                <span className="font-medium">{a.name}</span>
                                <span className="text-muted-foreground">· {a.size}</span>
                              </a>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </li>
                ))}
              </ul>

              {/* Zone de réponse : client et ingénieur seulement — l'admin lit en lecture seule */}
              {!closed && (isEngineer || isClient) && (
                <div className="border-t p-4">
                  <Textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    placeholder={isClient ? "Écrire une réponse…" : "Réponse, note ou procédure à transmettre…"}
                    rows={3}
                  />

                  {pendingFiles.length > 0 && (
                    <ul className="mt-2 flex flex-wrap gap-2">
                      {pendingFiles.map((f, i) => (
                        <li key={i} className="inline-flex items-center gap-2 rounded-md border bg-secondary/50 px-2 py-1 text-xs">
                          <FileText className="h-3.5 w-3.5 text-accent" />
                          <span className="max-w-[180px] truncate font-medium">{f.name}</span>
                          <button
                            type="button"
                            onClick={() => setPendingFiles((arr) => arr.filter((_, j) => j !== i))}
                            className="text-muted-foreground hover:text-destructive"
                            aria-label="Retirer"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}

                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const files = Array.from(e.target.files ?? []);
                      if (files.length) setPendingFiles((arr) => [...arr, ...files]);
                    }}
                  />

                  <div className="mt-3 flex items-center justify-between">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Paperclip className="h-4 w-4" />
                      {isClient ? "Joindre un fichier" : "Joindre fichier / procédure"}
                    </Button>
                    <Button
                      variant="hero"
                      size="sm"
                      onClick={handleSend}
                      disabled={!reply.trim() && pendingFiles.length === 0}
                    >
                      <Send className="h-4 w-4" /> Envoyer
                    </Button>
                  </div>
                </div>
              )}

              {/* Message lecture seule pour l'admin */}
              {!closed && isAdmin && (
                <div className="border-t px-5 py-3">
                  <p className="text-xs text-muted-foreground italic">
                    En tant qu'administrateur, vous consultez ce ticket en lecture seule. Utilisez le panneau latéral pour attribuer ou gérer l'escalade.
                  </p>
                </div>
              )}
            </Card>
          </div>

          {/* Sidebar */}
          <aside className="space-y-4">
            <Card className="p-5">
              <h3 className="text-sm font-semibold">Détails</h3>
              <dl className="mt-3 space-y-2 text-sm">
                <Detail label="Statut"><StatusBadge status={ticket.status} /></Detail>
                <Detail label="Priorité"><PriorityBadge priority={ticket.priority} /></Detail>
                <Detail label="Catégorie">{ticket.category}</Detail>
                <Detail label="Client">{ticket.clientName}</Detail>
                <Detail label="Équipement">
                  <div className="text-right">
                    <div>{ticket.equipmentLabel}</div>
                    <div className="font-mono text-xs text-muted-foreground">{ticket.equipmentSerial}</div>
                  </div>
                </Detail>
                <Detail label="Assigné">{ticket.assigneeName ?? "Non assigné"}</Detail>
                <Detail label="Créé le">{fmtDateTime(ticket.createdAt)}</Detail>
                <Detail label="Mis à jour">{fmtDateTime(ticket.updatedAt)}</Detail>
                {!closed && (
                  <Detail label="SLA">
                    <span className={`text-xs font-medium ${sla.tone}`}>{sla.text}</span>
                  </Detail>
                )}
              </dl>
            </Card>

            {/* CDC Ingénieur : répondre, escalader, clôturer, mettre en attente */}
            {isEngineer && !closed && (
              <Card className="p-5 space-y-2">
                <h3 className="text-sm font-semibold">Actions ingénieur</h3>
                <Button variant="outline" size="sm" className="w-full" onClick={() => handleStatusChange("en_cours")}>
                  Prendre en charge
                </Button>
                <Button variant="outline" size="sm" className="w-full" onClick={() => handleStatusChange("en_attente")}>
                  Mettre en attente
                </Button>
                <Button variant="outline" size="sm" className="w-full" onClick={handleEscalate}>
                  <AlertTriangle className="h-4 w-4" /> Escalader
                </Button>
                <Button variant="hero" size="sm" className="w-full" onClick={() => handleStatusChange("resolu")}>
                  <CheckCircle2 className="h-4 w-4" /> Marquer résolu
                </Button>
              </Card>
            )}

            {/* CDC Super Admin : attribution + gestion escalade uniquement */}
            {isAdmin && (
              <Card className="p-5 space-y-3">
                <h3 className="text-sm font-semibold">Actions admin</h3>
                <div className="space-y-1.5">
                  <p className="text-xs text-muted-foreground">Attribuer à un ingénieur</p>
                  <Select
                    value={ticket.assigneeId ?? ""}
                    onValueChange={handleAssign}
                  >
                    <SelectTrigger className="w-full text-sm">
                      <SelectValue placeholder="Sélectionner un ingénieur…" />
                    </SelectTrigger>
                    <SelectContent>
                      {engineers.map((e) => (
                        <SelectItem key={e.id} value={e.id}>{e.fullName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {ticket.escalated && (
                  <Button variant="outline" size="sm" className="w-full" onClick={handleDeescalate}>
                    Lever l'escalade
                  </Button>
                )}
                {!ticket.escalated && (
                  <p className="text-xs text-muted-foreground italic">Aucune escalade active sur ce ticket.</p>
                )}
              </Card>
            )}

            {/* CDC Client : confirmer fermeture si résolu */}
            {isClient && ticket.status === "resolu" && (
              <Card className="p-5 space-y-2">
                <h3 className="text-sm font-semibold">Validation</h3>
                <p className="text-xs text-muted-foreground">
                  L'ingénieur a marqué ce ticket comme résolu. Confirmez la fermeture ou rouvrez si besoin.
                </p>
                <Button variant="hero" size="sm" className="w-full" onClick={() => handleStatusChange("ferme")}>
                  Confirmer la fermeture
                </Button>
                <Button variant="outline" size="sm" className="w-full" onClick={() => handleStatusChange("en_cours")}>
                  Rouvrir le ticket
                </Button>
              </Card>
            )}
          </aside>
        </div>
      </main>
    </>
  );
};

const Detail = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="flex items-start justify-between gap-3">
    <dt className="text-xs text-muted-foreground">{label}</dt>
    <dd className="text-right text-sm">{children}</dd>
  </div>
);

export default TicketDetail;
