import { useState } from "react";
import { User, Lock, Phone, Building2, Eye, EyeOff, CheckCircle2 } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { usersService } from "@/services/api";
import { toast } from "@/hooks/use-toast";

const roleLabel: Record<string, string> = {
  client: "Client", engineer: "Ingénieur", commercial: "Commercial", admin: "Super Admin",
};
const roleColor: Record<string, string> = {
  client: "bg-info/10 text-info",
  engineer: "bg-accent/15 text-accent",
  commercial: "bg-success/10 text-success",
  admin: "bg-primary/10 text-primary",
};

const ProfilePage = () => {
  const { user } = useAuth();

  const [infoSuccess, setInfoSuccess] = useState(false);
  const [pwdSuccess, setPwdSuccess]   = useState(false);
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew]         = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [pwdError, setPwdError]       = useState("");

  if (!user) return null;

  // Modifier infos personnelles (nom, téléphone, entreprise)
  const handleInfoSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await usersService.update(user.id, {
      fullName: String(fd.get("fullName")),
      phone:    String(fd.get("phone") ?? "") || undefined,
      company:  String(fd.get("company") ?? "") || undefined,
    });
    setInfoSuccess(true);
    setTimeout(() => setInfoSuccess(false), 3000);
    toast({ title: "Profil mis à jour" });
  };

  // Modifier mot de passe
  const handlePasswordSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const currentPwd = String(fd.get("currentPassword"));
    const newPwd     = String(fd.get("newPassword"));
    const confirmPwd = String(fd.get("confirmPassword"));

    if (newPwd.length < 8) {
      setPwdError("Le nouveau mot de passe doit contenir au moins 8 caractères.");
      return;
    }
    if (newPwd !== confirmPwd) {
      setPwdError("Les mots de passe ne correspondent pas.");
      return;
    }
    if (!currentPwd) {
      setPwdError("Veuillez saisir votre mot de passe actuel.");
      return;
    }
    setPwdError("");

    // Côté mock : toujours OK — Django vérifiera currentPwd avant d'accepter
    await usersService.changePassword(user.id, currentPwd, newPwd);

    setPwdSuccess(true);
    setTimeout(() => setPwdSuccess(false), 3000);
    (e.target as HTMLFormElement).reset();
    toast({ title: "Mot de passe modifié avec succès" });
  };

  return (
    <>
      <AppHeader title="Mon profil" subtitle="Gérer vos informations et votre mot de passe" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <div className="mx-auto max-w-2xl space-y-6">

          {/* Carte identité */}
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-xl font-bold text-primary">
                {user.initials}
              </div>
              <div>
                <h2 className="text-lg font-bold">{user.fullName}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                <span className={`mt-1 inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${roleColor[user.role]}`}>
                  {roleLabel[user.role]}
                </span>
              </div>
            </div>
          </Card>

          {/* Modifier informations personnelles */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-5">
              <User className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold">Informations personnelles</h3>
            </div>
            <form onSubmit={handleInfoSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="fullName">Nom complet *</Label>
                  <Input id="fullName" name="fullName" defaultValue={user.fullName} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">
                    <span className="inline-flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> Téléphone</span>
                  </Label>
                  <Input id="phone" name="phone" type="tel" defaultValue={user.phone ?? ""} placeholder="+216 XX XXX XXX" />
                </div>
                {(user.role === "client" || user.role === "commercial") && (
                  <div className="space-y-2">
                    <Label htmlFor="company">
                      <span className="inline-flex items-center gap-1.5"><Building2 className="h-3.5 w-3.5" /> Entreprise</span>
                    </Label>
                    <Input id="company" name="company" defaultValue={user.company ?? ""} />
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between">
                {infoSuccess && (
                  <span className="inline-flex items-center gap-1.5 text-sm text-success">
                    <CheckCircle2 className="h-4 w-4" /> Informations mises à jour
                  </span>
                )}
                <Button type="submit" variant="hero" size="sm" className="ml-auto">
                  Enregistrer les modifications
                </Button>
              </div>
            </form>
          </Card>

          {/* Modifier mot de passe */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-5">
              <Lock className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold">Modifier le mot de passe</h3>
            </div>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              {/* Mot de passe actuel */}
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Mot de passe actuel *</Label>
                <div className="relative">
                  <Input
                    id="currentPassword" name="currentPassword"
                    type={showCurrent ? "text" : "password"}
                    required
                    onChange={() => setPwdError("")}
                  />
                  <button type="button" onClick={() => setShowCurrent(!showCurrent)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              {/* Nouveau mot de passe */}
              <div className="space-y-2">
                <Label htmlFor="newPassword">Nouveau mot de passe *</Label>
                <div className="relative">
                  <Input
                    id="newPassword" name="newPassword"
                    type={showNew ? "text" : "password"}
                    placeholder="Minimum 8 caractères"
                    required
                    onChange={() => setPwdError("")}
                  />
                  <button type="button" onClick={() => setShowNew(!showNew)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              {/* Confirmer */}
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe *</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword" name="confirmPassword"
                    type={showConfirm ? "text" : "password"}
                    placeholder="Répétez le nouveau mot de passe"
                    required
                    onChange={() => setPwdError("")}
                  />
                  <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {pwdError && <p className="text-xs text-destructive">{pwdError}</p>}
              </div>
              <div className="flex items-center justify-between">
                {pwdSuccess && (
                  <span className="inline-flex items-center gap-1.5 text-sm text-success">
                    <CheckCircle2 className="h-4 w-4" /> Mot de passe modifié
                  </span>
                )}
                <Button type="submit" variant="hero" size="sm" className="ml-auto">
                  Changer le mot de passe
                </Button>
              </div>
            </form>
          </Card>

        </div>
      </main>
    </>
  );
};

export default ProfilePage;
