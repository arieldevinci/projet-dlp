import { useEffect, useState } from "react";
import { Plus, Mail, Phone, Building2, Search } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { usersService } from "@/services/api";
import type { User } from "@/types";
import { toast } from "@/hooks/use-toast";

const CommercialClients = () => {
  const [list, setList] = useState<User[]>([]);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const load = () => usersService.byRole("client").then(setList);

  useEffect(() => {
    load();
  }, []);

  const filtered = list.filter(
    (c) =>
      (c.company ?? "").toLowerCase().includes(query.toLowerCase()) ||
      c.fullName.toLowerCase().includes(query.toLowerCase()) ||
      c.email.toLowerCase().includes(query.toLowerCase()),
  );

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await usersService.create({
      email: String(fd.get("email")),
      fullName: String(fd.get("fullName")),
      role: "client",
      company: String(fd.get("company")),
      phone: String(fd.get("phone") ?? ""),
    });
    toast({ title: "Client créé", description: "Un email d'invitation lui sera envoyé." });
    setOpen(false);
    load();
  };

  return (
    <>
      <AppHeader
        title="Clients"
        subtitle="Portefeuille clients sous contrat"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nouveau client</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nouveau client</DialogTitle>
                <DialogDescription>
                  Le client recevra un email d'invitation pour activer son espace.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="company">Entreprise *</Label>
                    <Input id="company" name="company" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Contact *</Label>
                    <Input id="fullName" name="fullName" required placeholder="Prénom Nom" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" name="email" type="email" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input id="phone" name="phone" type="tel" />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
                  <Button type="submit" variant="hero">Créer le client</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <div className="mb-4 relative max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher un client…" className="pl-9" />
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <Card key={c.id} className="p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-accent text-accent-foreground font-bold">
                  {c.initials}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold truncate">{c.company}</p>
                  <p className="text-xs text-muted-foreground truncate">{c.fullName}</p>
                </div>
              </div>
              <dl className="mt-4 space-y-1.5 border-t pt-3 text-xs">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" /> {c.email}
                </div>
                {c.phone && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="h-3.5 w-3.5" /> {c.phone}
                  </div>
                )}
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Building2 className="h-3.5 w-3.5" /> Client depuis {new Date(c.createdAt).toLocaleDateString("fr-FR")}
                </div>
              </dl>
            </Card>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full p-8 text-center text-sm text-muted-foreground">Aucun client.</p>
          )}
        </div>
      </main>
    </>
  );
};

export default CommercialClients;
