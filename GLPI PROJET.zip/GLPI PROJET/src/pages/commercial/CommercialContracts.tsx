import { useEffect, useState } from "react";
import { Plus, RefreshCw, Search, Calendar, FileSignature, Trash2, Edit2 } from "lucide-react";

import { AppHeader } from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { contractsService, equipmentsService, usersService } from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import type { Contract, Equipment, User } from "@/types";
import { fmtDate } from "@/lib/format";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const statusConfig: Record<Contract["status"], { label: string; classes: string }> = {
  actif: { label: "Actif", classes: "bg-success/10 text-success ring-success/30" },
  expire_bientot: { label: "Expire bientôt", classes: "bg-warning/15 text-warning-foreground ring-warning/40" },
  expire: { label: "Expiré", classes: "bg-destructive/10 text-destructive ring-destructive/30" },
  renouvele: { label: "Renouvelé", classes: "bg-info/10 text-info ring-info/30" },
};

const CommercialContracts = () => {
  const { user } = useAuth();
  // Seul le commercial peut créer et renouveler des contrats (CDC)
  const canEdit = user?.role === "commercial";

  const [list, setList] = useState<Contract[]>([]);
  const [clients, setClients] = useState<User[]>([]);
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [renewId, setRenewId] = useState<string | null>(null);
  const [selectedEquipments, setSelectedEquipments] = useState<string[]>([]);
  const [editId, setEditId] = useState<string | null>(null);
  const [editEquipments, setEditEquipments] = useState<string[]>([]);

  const load = () => contractsService.list().then(setList);

  useEffect(() => {
    load();
    usersService.byRole("client").then(setClients);
    equipmentsService.list().then(setEquipments);
  }, []);

  const filtered = list.filter(
    (c) =>
      c.reference.toLowerCase().includes(query.toLowerCase()) ||
      c.clientName.toLowerCase().includes(query.toLowerCase()),
  );

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const client = clients.find((c) => c.id === String(fd.get("clientId")));
    if (!client) return;
    await contractsService.create({
      clientId: client.id,
      clientName: client.company ?? client.fullName,
      startDate: String(fd.get("startDate")),
      endDate: String(fd.get("endDate")),
      scope: String(fd.get("scope")),
      equipmentIds: selectedEquipments,
      amount: Number(fd.get("amount") || 0),
    });
    toast({ title: "Contrat créé", description: `Pour ${client.company ?? client.fullName}` });
    setOpen(false);
    setSelectedEquipments([]);
    load();
  };

  const handleRenew = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (!renewId) return;
    await contractsService.renew(renewId, String(fd.get("newStartDate")), String(fd.get("newEndDate")));
    toast({ title: "Contrat renouvelé", description: "Le contrat a été renouvelé avec succès." });
    setRenewId(null);
    load();
  };

  const handleRemove = async (id: string) => {
    await contractsService.remove(id);
    toast({ title: "Contrat supprimé" });
    load();
  };

  const handleUpdateScope = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editId) return;
    const fd = new FormData(e.currentTarget);
    await contractsService.updateScope(editId, {
      scope: String(fd.get("scope")),
      equipmentIds: editEquipments,
    });
    toast({ title: "Périmètre mis à jour" });
    setEditId(null);
    load();
  };

  const editing = editId ? list.find((c) => c.id === editId) : null;
  const renewing = renewId ? list.find((c) => c.id === renewId) : null;

  // Filtre les équipements selon le client sélectionné dans le dialog
  const [createClientId, setCreateClientId] = useState<string>("");
  const equipmentsForCreate = equipments.filter((eq) => !createClientId || eq.clientId === createClientId);

  return (
    <>
      <AppHeader
        title="Contrats"
        subtitle={canEdit ? "Création, suivi et renouvellement" : "Consultation des contrats"}
        actions={
          canEdit ? (
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setSelectedEquipments([]); setCreateClientId(""); } }}>
            <DialogTrigger asChild>
              <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nouveau contrat</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nouveau contrat</DialogTitle>
                <DialogDescription>Définissez le périmètre et les dates de validité.</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="clientId">Client *</Label>
                    <Select name="clientId" value={createClientId} onValueChange={setCreateClientId} required>
                      <SelectTrigger id="clientId"><SelectValue placeholder="Sélectionner…" /></SelectTrigger>
                      <SelectContent>
                        {clients.map((c) => (
                          <SelectItem key={c.id} value={c.id}>{c.company ?? c.fullName}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount">Montant annuel (TND)</Label>
                    <Input id="amount" name="amount" type="number" min={0} step={500} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Date de début *</Label>
                    <Input id="startDate" name="startDate" type="date" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">Date de fin *</Label>
                    <Input id="endDate" name="endDate" type="date" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="scope">Périmètre couvert *</Label>
                  <Textarea
                    id="scope"
                    name="scope"
                    required
                    rows={3}
                    placeholder="Ex : Maintenance préventive trimestrielle + assistance 24/7…"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Équipements couverts ({selectedEquipments.length})</Label>
                  <div className="max-h-44 overflow-y-auto rounded-md border bg-secondary/30 p-2">
                    {equipmentsForCreate.length === 0 && (
                      <p className="p-2 text-xs text-muted-foreground">Sélectionnez d'abord un client.</p>
                    )}
                    {equipmentsForCreate.map((eq) => (
                      <label key={eq.id} className="flex items-center gap-2 rounded p-2 cursor-pointer hover:bg-background">
                        <Checkbox
                          checked={selectedEquipments.includes(eq.id)}
                          onCheckedChange={(checked) => {
                            setSelectedEquipments((s) =>
                              checked ? [...s, eq.id] : s.filter((id) => id !== eq.id),
                            );
                          }}
                        />
                        <span className="text-sm">{eq.serial} — {eq.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
                  <Button type="submit" variant="hero">Créer le contrat</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          ) : undefined
        }
      />

      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between border-b p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher par client ou référence…"
                className="w-full pl-9 md:w-80"
              />
            </div>
            <span className="text-xs text-muted-foreground">{filtered.length} contrat{filtered.length > 1 ? "s" : ""}</span>
          </div>

          <ul className="divide-y">
            {filtered.map((c) => {
              const cfg = statusConfig[c.status];
              const daysLeft = Math.ceil((new Date(c.endDate).getTime() - Date.now()) / (1000 * 3600 * 24));
              return (
                <li key={c.id} className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/5 text-primary">
                    <FileSignature className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{c.reference}</span>
                      <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", cfg.classes)}>
                        {cfg.label}
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-medium">{c.clientName}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground line-clamp-1">{c.scope}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" /> {fmtDate(c.startDate)} → {fmtDate(c.endDate)}</span>
                      <span>{c.equipmentIds.length} équipement{c.equipmentIds.length > 1 ? "s" : ""}</span>
                      {c.amount && <span>{c.amount.toLocaleString("fr-FR")} TND/an</span>}
                      {(c.status === "actif" || c.status === "expire_bientot") && (
                        <span className={daysLeft < 60 ? "text-warning-foreground font-medium" : ""}>
                          {daysLeft > 0 ? `${daysLeft}j restants` : "Expiré"}
                        </span>
                      )}
                    </div>
                  </div>
                  {canEdit && (c.status === "expire" || c.status === "expire_bientot") && (
                    <Button variant="hero" size="sm" onClick={() => setRenewId(c.id)}>
                      <RefreshCw className="h-4 w-4" /> Renouveler
                    </Button>
                  )}
                  {canEdit && (
                    <Button variant="outline" size="sm" onClick={() => {
                      setEditId(c.id);
                      setEditEquipments(c.equipmentIds);
                    }}>
                      <Edit2 className="h-4 w-4" /> Modifier
                    </Button>
                  )}
                  {canEdit && (
                    <Button variant="ghost" size="sm" onClick={() => handleRemove(c.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  )}
                </li>
              );
            })}
            {filtered.length === 0 && (
              <li className="p-12 text-center text-sm text-muted-foreground">Aucun contrat.</li>
            )}
          </ul>
        </Card>
      </main>

      <Dialog open={!!renewId} onOpenChange={(o) => !o && setRenewId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renouveler {renewing?.reference}</DialogTitle>
            <DialogDescription>
              Définissez la nouvelle date de fin du contrat pour {renewing?.clientName}.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRenew} className="space-y-4">
            <div className="rounded-md bg-secondary/40 px-4 py-3 text-xs text-muted-foreground">
              Contrat actuel : {renewing && `${fmtDate(renewing.startDate)} → ${fmtDate(renewing.endDate)}`}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="newStartDate">Nouvelle date de début *</Label>
                <Input id="newStartDate" name="newStartDate" type="date" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newEndDate">Nouvelle date de fin *</Label>
                <Input id="newEndDate" name="newEndDate" type="date" required />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setRenewId(null)}>Annuler</Button>
              <Button type="submit" variant="hero">Renouveler le contrat</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      {/* Dialog modifier périmètre */}
      <Dialog open={!!editId} onOpenChange={(o) => !o && setEditId(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Modifier le périmètre — {editing?.reference}</DialogTitle>
            <DialogDescription>
              Mettez à jour le périmètre couvert et les équipements pour {editing?.clientName}.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateScope} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="scope">Périmètre couvert *</Label>
              <Textarea
                id="scope"
                name="scope"
                required
                rows={4}
                defaultValue={editing?.scope ?? ""}
                placeholder="Ex : Maintenance préventive trimestrielle + assistance 24/7…"
              />
            </div>
            <div className="space-y-2">
              <Label>Équipements couverts ({editEquipments.length} sélectionné{editEquipments.length > 1 ? "s" : ""})</Label>
              <div className="max-h-44 overflow-y-auto rounded-md border bg-secondary/30 p-2">
                {equipments
                  .filter((eq) => eq.clientId === editing?.clientId)
                  .map((eq) => (
                    <label key={eq.id} className="flex items-center gap-2 rounded p-2 cursor-pointer hover:bg-background">
                      <Checkbox
                        checked={editEquipments.includes(eq.id)}
                        onCheckedChange={(checked) => {
                          setEditEquipments((s) =>
                            checked ? [...s, eq.id] : s.filter((id) => id !== eq.id),
                          );
                        }}
                      />
                      <span className="text-sm">{eq.serial} — {eq.label}</span>
                    </label>
                  ))}
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setEditId(null)}>Annuler</Button>
              <Button type="submit" variant="hero">Enregistrer les modifications</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CommercialContracts;
