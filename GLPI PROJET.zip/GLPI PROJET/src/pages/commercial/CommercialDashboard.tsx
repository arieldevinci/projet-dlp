import { useEffect, useState } from "react";
import { Briefcase, FileSignature, RefreshCw, Users, Calendar } from "lucide-react";
import { Link } from "react-router-dom";

import { AppHeader } from "@/components/layout/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { contractsService, usersService } from "@/services/api";
import type { Contract, User } from "@/types";
import { fmtDate } from "@/lib/format";

const CommercialDashboard = () => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [clients, setClients] = useState<User[]>([]);

  useEffect(() => {
    contractsService.list().then(setContracts);
    usersService.byRole("client").then(setClients);
  }, []);

  const active = contracts.filter((c) => c.status === "actif");
  const expiringSoon = contracts.filter((c) => c.status === "expire_bientot");
  const expired = contracts.filter((c) => c.status === "expire");
  const revenue = active.reduce((s, c) => s + (c.amount ?? 0), 0);

  return (
    <>
      <AppHeader title="Espace commercial" subtitle="Pilotage des contrats et du portefeuille client" />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 animate-fade-in">
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Contrats actifs" value={active.length} icon={FileSignature} accent="success" />
          <KpiCard label="À renouveler" value={expiringSoon.length} icon={RefreshCw} accent="warning" />
          <KpiCard label="Expirés" value={expired.length} icon={Calendar} accent="destructive" />
          <KpiCard label="Clients" value={clients.length} icon={Users} accent="info" />
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-2">
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Revenus annuels récurrents</h3>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="mt-2 text-3xl font-bold">{revenue.toLocaleString("fr-FR")} TND</p>
            <p className="text-xs text-muted-foreground">Issus des contrats actifs</p>
          </Card>

          <Card className="overflow-hidden">
            <div className="border-b p-5">
              <h3 className="text-sm font-semibold">À renouveler en priorité</h3>
              <p className="text-xs text-muted-foreground">Contrats expirant dans les 60 jours</p>
            </div>
            <ul className="divide-y">
              {expiringSoon.length === 0 && (
                <li className="p-6 text-center text-sm text-muted-foreground">Tout est à jour 🎉</li>
              )}
              {expiringSoon.map((c) => (
                <li key={c.id} className="flex items-center justify-between p-4">
                  <div>
                    <p className="text-sm font-medium">{c.clientName}</p>
                    <p className="text-xs text-muted-foreground">{c.reference} · expire le {fmtDate(c.endDate)}</p>
                  </div>
                  <Button variant="hero" size="sm" asChild>
                  <Link to="/co/contrats"><RefreshCw className="h-4 w-4" /> Renouveler</Link>
                </Button>
                </li>
              ))}
            </ul>
          </Card>
        </section>
      </main>
    </>
  );
};

export default CommercialDashboard;
