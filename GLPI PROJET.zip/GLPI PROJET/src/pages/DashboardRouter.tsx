import { useAuth } from "@/contexts/AuthContext";
import ClientDashboard from "@/pages/client/ClientDashboard";
import EngineerDashboard from "@/pages/engineer/EngineerDashboard";
import CommercialDashboard from "@/pages/commercial/CommercialDashboard";
import AdminDashboard from "@/pages/admin/AdminDashboard";

/** Aiguillage du dashboard selon le rôle de l'utilisateur connecté. */
const DashboardRouter = () => {
  const { user } = useAuth();
  if (!user) return null;
  switch (user.role) {
    case "client": return <ClientDashboard />;
    case "engineer": return <EngineerDashboard />;
    case "commercial": return <CommercialDashboard />;
    case "admin": return <AdminDashboard />;
  }
};

export default DashboardRouter;
