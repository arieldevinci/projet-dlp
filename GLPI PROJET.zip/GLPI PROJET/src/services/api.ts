/**
 * Couche service — point d'intégration unique avec le futur back Django.
 *
 * Pour brancher l'API réelle :
 *  1. Remplacer les fonctions de ce fichier par des `fetch(API_URL + ...)`
 *  2. Conserver les mêmes signatures (Promise<...>) → aucun changement UI
 *  3. Gérer le token JWT dans un intercepteur (cf. AuthContext)
 *
 * Toutes les fonctions sont async pour mimer la latence réseau.
 */

import {
  contracts as seedContracts,
  equipments as seedEquipments,
  kbArticles as seedKb,
  maintenances as seedMaintenances,
  tickets as seedTickets,
  users as seedUsers,
} from "@/data/seed";
import type {
  Contract,
  Equipment,
  KbArticle,
  Maintenance,
  Ticket,
  TicketMessage,
  User,
  UserRole,
} from "@/types";

// ---- Stockage en mémoire (remplacé plus tard par appels HTTP) ----
let _users = [...seedUsers];
let _equipments = [...seedEquipments];
let _contracts = [...seedContracts];
let _tickets = [...seedTickets];
let _maintenances = [...seedMaintenances];

const delay = (ms = 200) => new Promise((r) => setTimeout(r, ms));

// ============== Users ==============
export const usersService = {
  async list(): Promise<User[]> {
    await delay();
    return [..._users];
  },
  async byRole(role: UserRole): Promise<User[]> {
    await delay();
    return _users.filter((u) => u.role === role);
  },
  async byId(id: string): Promise<User | undefined> {
    await delay();
    return _users.find((u) => u.id === id);
  },
  async create(u: Omit<User, "id" | "createdAt" | "initials">): Promise<User> {
    await delay();
    const created: User = {
      ...u,
      id: `u-${Date.now()}`,
      createdAt: new Date().toISOString(),
      initials: u.fullName.split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase(),
    };
    _users = [created, ..._users];
    return created;
  },
  async remove(id: string): Promise<void> {
    await delay();
    _users = _users.filter((u) => u.id !== id);
  },
  async update(id: string, patch: Partial<Pick<User, "fullName" | "phone" | "company">>): Promise<User | undefined> {
    await delay();
    _users = _users.map((u) => {
      if (u.id !== id) return u;
      const updated = { ...u, ...patch };
      // Recalculer les initiales si le nom change
      if (patch.fullName) {
        const parts = patch.fullName.trim().split(" ");
        updated.initials = parts.length >= 2
          ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
          : parts[0].slice(0, 2).toUpperCase();
      }
      return updated;
    });
    return _users.find((u) => u.id === id);
  },
  // Côté mock : simulation — Django vérifiera currentPassword avant d'accepter
  async changePassword(_id: string, _currentPassword: string, _newPassword: string): Promise<boolean> {
    await delay();
    return true; // Simulé — toujours OK en mode mock
  },
};

// ============== Equipments ==============
export const equipmentsService = {
  async list(): Promise<Equipment[]> {
    await delay();
    return [..._equipments];
  },
  async byClient(clientId: string): Promise<Equipment[]> {
    await delay();
    return _equipments.filter((e) => e.clientId === clientId);
  },
};

// ============== Contracts ==============
export const contractsService = {
  async list(): Promise<Contract[]> {
    await delay();
    return [..._contracts];
  },
  async byClient(clientId: string): Promise<Contract[]> {
    await delay();
    return _contracts.filter((c) => c.clientId === clientId);
  },
  async create(c: Omit<Contract, "id" | "reference" | "status">): Promise<Contract> {
    await delay();
    const created: Contract = {
      ...c,
      id: `ctr-${Date.now()}`,
      reference: `CTR-${new Date().getFullYear()}-${String(_contracts.length + 1).padStart(3, "0")}`,
      status: "actif",
    };
    _contracts = [created, ..._contracts];
    return created;
  },
  async byEngineer(engineerId: string): Promise<Contract[]> {
    await delay();
    // Récupère les contrats des clients assignés à cet ingénieur
    const engineer = _users.find((u) => u.id === engineerId);
    if (!engineer) return [];
    const assignedClientIds = _users
      .filter((u) => u.role === "client" && u.assignedEngineerId === engineerId)
      .map((u) => u.id);
    // Fallback : si aucun client assigné, retourne les contrats liés aux maintenances de cet ingénieur
    if (assignedClientIds.length === 0) {
      const clientIdsFromMaint = [...new Set(
        _maintenances.filter((m) => m.engineerId === engineerId).map((m) => m.clientId)
      )];
      return _contracts.filter((c) => clientIdsFromMaint.includes(c.clientId));
    }
    return _contracts.filter((c) => assignedClientIds.includes(c.clientId));
  },
  async renew(id: string, newStartDate: string, newEndDate: string): Promise<Contract | undefined> {
    await delay();
    _contracts = _contracts.map((c) =>
      c.id === id ? { ...c, startDate: newStartDate, endDate: newEndDate, status: "renouvele" } : c,
    );
    return _contracts.find((c) => c.id === id);
  },
  async remove(id: string): Promise<void> {
    await delay();
    _contracts = _contracts.filter((c) => c.id !== id);
  },
  async updateScope(id: string, patch: { scope: string; equipmentIds: string[] }): Promise<Contract | undefined> {
    await delay();
    _contracts = _contracts.map((c) =>
      c.id === id ? { ...c, ...patch } : c,
    );
    return _contracts.find((c) => c.id === id);
  },
};

// ============== Tickets ==============
export const ticketsService = {
  async list(): Promise<Ticket[]> {
    await delay();
    return [..._tickets];
  },
  async byClient(clientId: string): Promise<Ticket[]> {
    await delay();
    return _tickets.filter((t) => t.clientId === clientId);
  },
  async byEngineer(engineerId: string): Promise<Ticket[]> {
    await delay();
    return _tickets.filter((t) => t.assigneeId === engineerId);
  },
  async byId(id: string): Promise<Ticket | undefined> {
    await delay();
    return _tickets.find((t) => t.id === id || t.reference === id);
  },
  async create(t: Omit<Ticket, "id" | "reference" | "createdAt" | "updatedAt" | "messages">): Promise<Ticket> {
    await delay();
    const ref = `TKT-${2419 + _tickets.length}`;
    const created: Ticket = {
      ...t,
      id: ref.toLowerCase(),
      reference: ref,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    _tickets = [created, ..._tickets];
    return created;
  },
  async update(id: string, patch: Partial<Ticket>): Promise<Ticket | undefined> {
    await delay();
    _tickets = _tickets.map((t) =>
      t.id === id ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t,
    );
    return _tickets.find((t) => t.id === id);
  },
  async addMessage(id: string, message: Omit<TicketMessage, "id" | "createdAt">): Promise<Ticket | undefined> {
    await delay();
    const m: TicketMessage = {
      ...message,
      id: `msg-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    _tickets = _tickets.map((t) =>
      t.id === id
        ? { ...t, messages: [...t.messages, m], updatedAt: new Date().toISOString() }
        : t,
    );
    return _tickets.find((t) => t.id === id);
  },
};

// ============== Maintenances ==============
export const maintenancesService = {
  async list(): Promise<Maintenance[]> {
    await delay();
    return [..._maintenances];
  },
  async byClient(clientId: string): Promise<Maintenance[]> {
    await delay();
    return _maintenances.filter((m) => m.clientId === clientId);
  },
  async byEngineer(engineerId: string): Promise<Maintenance[]> {
    await delay();
    return _maintenances.filter((m) => m.engineerId === engineerId);
  },
  async create(m: Omit<Maintenance, "id" | "reference">): Promise<Maintenance> {
    await delay();
    const created: Maintenance = {
      ...m,
      id: `mnt-${Date.now()}`,
      reference: `MNT-${new Date().getFullYear()}-${String(_maintenances.length + 1).padStart(3, "0")}`,
    };
    _maintenances = [created, ..._maintenances];
    return created;
  },
  async uploadReport(id: string, fileName: string): Promise<Maintenance | undefined> {
    await delay();
    _maintenances = _maintenances.map((m) =>
      m.id === id
        ? { ...m, status: "realisee", reportPdfName: fileName, reportUploadedAt: new Date().toISOString() }
        : m,
    );
    return _maintenances.find((m) => m.id === id);
  },
  async update(id: string, patch: Partial<Pick<Maintenance, "type" | "scheduledAt" | "durationMinutes" | "notes">>): Promise<Maintenance | undefined> {
    await delay();
    _maintenances = _maintenances.map((m) => (m.id === id ? { ...m, ...patch } : m));
    return _maintenances.find((m) => m.id === id);
  },
};

// ============== KB ==============
export const kbService = {
  async list(): Promise<KbArticle[]> {
    await delay();
    return [...seedKb];
  },
};
